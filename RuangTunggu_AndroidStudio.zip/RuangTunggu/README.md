# RuangTunggu — Aplikasi Pendaftaran & Pemantauan Antrean Pasien

Aplikasi Android native (Kotlin, XML Views, ViewBinding) untuk mendaftar antrean rumah sakit, memantau posisi antrean,
menerima pengingat saat giliran mendekat, serta melihat riwayat dan membatalkan antrean.
Nama aplikasi diambil dari wireframe (**RuangTunggu**, tagline *"Antre tanpa ribet, sehat tanpa menunggu"*) dan dapat diganti
lewat `app/src/main/res/values/strings.xml` (`app_name`, `app_tagline`).

> ## ⚠️ Status verifikasi (baca dulu)
> Project ini **belum pernah di-build atau dijalankan di emulator/perangkat**. Lingkungan tempat project ini dibuat tidak
> memiliki Android SDK maupun akses ke Gradle/Google Maven, sehingga *Gradle Sync, build, dan uji di emulator belum dilakukan*.
>
> Yang **sudah** diperiksa secara statis:
> - Seluruh 99 file XML well-formed.
> - Semua referensi `R.drawable / R.color / R.string / R.id / R.layout`, `@style`, atribut kustom, dan properti ViewBinding
>   di kode Kotlin cocok dengan resource yang ada (skrip pemeriksa), serta kurung kurawal/kurung Kotlin seimbang.
> - Seluruh 31 query SQL (diekstrak dari kode) valid terhadap skema di SQLite, dan logika pendaftaran/pembatalan
>   (slot terakhir, nomor unik, kuota kembali satu kali) disimulasikan dengan SQL yang sama.
>
> Yang **belum** dilakukan: kompilasi Kotlin, menjalankan unit test (`app/src/test`), dan pengujian tampilan di perangkat.
> Kemungkinan masih ada galat kompilasi/tampilan kecil; perbaiki dari pesan error Android Studio. Lihat bagian *Pengujian*.

## Teknologi
- Kotlin 1.9.24, Android Gradle Plugin 8.5.2, Gradle 8.7, JDK 17, `compileSdk/targetSdk 34`, `minSdk 26`
- XML Views + ViewBinding, Material Components 1.12 (tema Material 3), AndroidX
- Penyimpanan persisten: **SQLite** (`SQLiteOpenHelper`, transaksi). Dipilih agar tidak butuh plugin kapt/ksp (risiko build lebih kecil)
- `zxing:core` untuk QR pada tiket antrean
- Kata sandi di-hash PBKDF2-HMAC-SHA256 + salt (tidak disimpan/dicatat sebagai teks biasa)

## Persyaratan & cara menjalankan
1. Android Studio Koala (2024.1) atau lebih baru, JDK 17 (bawaan Android Studio).
2. `File ▸ Open…` → pilih folder `RuangTunggu` (root, yang berisi `settings.gradle.kts`).
3. Tunggu **Gradle Sync** (butuh internet pertama kali). Jika diminta, install Android SDK 34.
4. Jalankan `app` di emulator (API 26+) atau perangkat.
5. Data demo (rumah sakit, dokter, jadwal 7 hari ke depan) dibuat otomatis saat pertama dibuka.

### Alur uji cepat (mode demo)
1. Splash → *Mulai* ×4 → **Registrasi** (NIK 16 digit **dummy**, mis. `3515000000000001`; tanggal lahir format `Madiun, 20/04/2005`;
   kata sandi min. 8 karakter huruf+angka; centang CAPTCHA demo).
2. *Masuk sekarang* → Login (NIK atau email) → Beranda.
3. *Cari RS* → pilih RS → pilih poli → pilih dokter & jam → Konfirmasi → tiket (nomor pertama = **A-023** untuk Poli Anak).
4. Tab **Antrean**: lihat sisa antrean. Di panel **MODE DEMO** tekan *Petugas memanggil nomor berikutnya* hingga sisa ≤ 2 →
   notifikasi muncul (izinkan notifikasi di Android 13+). Centang *Simulasikan pengiriman gagal* untuk menguji jalur coba-ulang.
5. Tab **Riwayat** → *Batalkan* pada antrean aktif.
6. Uji slot penuh: jadwal `dr. Abdul Farid, Sp.A` 11:00 hari ini hanya punya **1 kuota**; jadwal `dr. Anggita` 13:00 sudah penuh (dicoret).
   Poli **Mata** tidak praktik hari ini → pesan "Jadwal belum tersedia". Pencarian "Klinik Mawar" → "Data tidak ditemukan".

## Daftar halaman ↔ wireframe SVG (36 file dibaca semuanya)
| Halaman aplikasi | Class / layout | SVG acuan |
|---|---|---|
| Splash + onboarding 3 halaman | `SplashActivity`, `activity_splash` | `01. Splashscreen`, `02. Splashscreen 1`, `03. Splashscreen 2`, `04. Splashscreen 3` |
| Login (+ galat) | `LoginActivity` | `Login`, `Login berhasil`, `Login gagal`, `Login berhasil masuk` |
| Login berhasil | `SuccessActivity` | `Login berhasil` |
| Registrasi (+ galat, berhasil) | `RegisterActivity`, `SuccessActivity` | `Registrasi`, `Pengisian registrasi`, `Pengisian registrasi salah`, `registrasi gagal`, `registrasi berhasil` |
| Lupa sandi | `ForgotPasswordActivity` | `Lupa sandi` |
| Verifikasi kode | `VerifyCodeActivity` | `verifikasi kode lupa kata sandi` |
| Kata sandi berhasil diubah | `SuccessActivity` | `Kata sandi berhasil dirubah` |
| Beranda | `HomeFragment` | `Beranda` |
| Profil + banner berhasil | `ProfileFragment` | `Profil`, `Profil berhasil` |
| Ubah profil (benar/gagal) | `EditProfileActivity` | `Ubah profil benar`, `Ubah profil gagal` |
| Cari RS & Poli (+ kosong) | `SearchHospitalActivity` | `Cari RS & Poli`, `Cari RS gagal` |
| Pilih poli | `SelectPoliActivity` | `Pilih poli`, `Poli terpilih` |
| Pilih dokter & jadwal | `SelectScheduleActivity` | `Pilih jadwal dokter` |
| Ringkasan konfirmasi / slot penuh | `SummaryActivity` | `RIngkasan konfirmasi pendaftaran`, `Slot penuh` |
| Pendaftaran berhasil / Detail antrean | `TicketActivity` | `Pendaftaran berhasil` |
| Pantau antrean (+ kosong) | `QueueFragment` | `Pantau antrean`, `Belum ada antrean aktif` |
| Notifikasi giliran | `LocalNotificationSender` | `Notifikasi` |
| Riwayat | `HistoryFragment` | `Riwayat antrean` |
| Dialog pembatalan / berhasil / gagal | `StatusDialog` | `Pembatalan antrean`, `Pembatalan berhasil`, `Pembatalan gagal` |

Pemetaan proses → halaman flowchart PDF (8 halaman) dan file implementasi ada di **TRACEABILITY.md**.

## Keputusan desain & asumsi (jujur, tidak diklaim berasal dari file)
- **Identitas login.** Flowchart hal. 1 menulis "NIK", pesan galatnya "email/password salah". Wireframe `Login.svg` memberi satu kolom
  **"NIK / Email"**. Kolom itu menerima keduanya (ada `@` → email, selain itu NIK). Pesan galat mengikuti wireframe: *"Email/password salah"*.
- **Registrasi.** Kolom "Email / No. HP" menerima salah satunya. "Tempat, tanggal lahir" satu kolom (`Kota, DD/MM/YYYY`).
  Aturan yang saya tetapkan sendiri: NIK 16 digit angka; kata sandi ≥ 8 karakter berisi huruf dan angka; email/HP/NIK harus unik.
- **CAPTCHA** hanya kotak centang lokal berlabel **"CAPTCHA DEMO"** — *bukan* proteksi bot sungguhan.
- **Lupa sandi (mode demo).** Tidak ada email/SMS yang dikirim. Kode 6 digit ditampilkan di layar dalam kotak berlabel
  "MODE DEMO". Kode berlaku 5 menit, maks. 5 percobaan. Wireframe tidak punya layar "kata sandi baru"; langkah itu
  saya tambahkan di `VerifyCodeActivity` (Langkah 2 dari 2). Jika akun tidak ditemukan ditampilkan "Akun tidak ditemukan"
  (pada produksi sebaiknya pesan netral agar akun tidak bisa ditebak).
- **Badge "Terverifikasi"** di wireframe Profil saya ganti **"Akun terdaftar"** karena tidak ada proses verifikasi identitas.
- **Nomor antrean** unik per (poli, tanggal), format `<kode poli>-<3 digit>` (Anak=A, Umum=B, Gigi=C, Kandungan=D, Mata=E, Penyakit Dalam=F).
  Penghitung awal didisetel demo (dilayani 18, terakhir 22) agar pasien pertama mendapat **A-023** seperti contoh flowchart/wireframe.
  Nomor tidak pernah dipakai ulang walau antrean dibatalkan.
- **Sisa antrean** = nomor pasien − nomor dilayani; **estimasi** = sisa × 5 menit (wireframe: 5 → 25 menit). Angka 5 menit ada di `AppConfig`.
- **Batas notifikasi** = 2 (wireframe: "sisa antrean ≤ 2"), dikonfigurasi di `AppConfig.NOTIF_THRESHOLD`.
- **Pembatalan** hanya jika status *Aktif* **dan** nomor belum sedang dilayani (teks wireframe: "sudah tidak aktif atau sedang dilayani petugas").
- Antrean yang nomornya sudah dilewati petugas, atau tanggalnya sudah lewat, otomatis menjadi **Selesai** (asumsi saya; flowchart tidak merinci siapa yang menyelesaikan).
- Satu pasien tidak boleh punya dua antrean *Aktif* pada jadwal yang sama.
- Jika pasien punya beberapa antrean aktif, halaman Pantau/Beranda menampilkan yang jadwalnya paling dekat.
- Data rumah sakit/dokter **fiktif** (nama RS dan foto diambil dari wireframe). Alamat/kontak adalah placeholder.
- Semua data bawaan memakai data dummy. Tidak ada NIK nyata. NIK/kata sandi tidak dicatat ke log.
- Layar dikunci portrait (sesuai wireframe).

## Yang berjalan lokal vs. yang butuh backend
| Fitur | Status |
|---|---|
| Registrasi, login, profil, pencarian, jadwal, antrean, riwayat, pembatalan | Berjalan **lokal** (SQLite di perangkat). Akun hanya ada di perangkat itu |
| Lupa sandi | **Simulasi** (kode ditampilkan di layar) |
| CAPTCHA | **Simulasi** |
| Petugas memperbarui nomor dilayani | **Simulasi** lewat tombol di panel MODE DEMO |
| Notifikasi "Giliran Anda sudah dekat" | **Notifikasi lokal** di perangkat yang sama. **Bukan FCM**; belum ada push lintas perangkat |
| Coba-ulang saat gagal kirim | Dijadwalkan (30 dtk, maks. 3×) tetapi hanya dievaluasi saat aplikasi dibuka/di-refresh — **tidak ada worker latar belakang** |
| Firebase Auth / Firestore / FCM | **Belum dikonfigurasi** (tidak ada `google-services.json`; tidak saya buat) |

### Mengaktifkan Firebase (langkah ringkas)
1. Buat proyek di Firebase Console, daftarkan app `com.example.ruangtunggu`, unduh `google-services.json` ke `app/`.
2. Tambahkan plugin `com.google.gms.google-services` dan dependensi Firebase BoM (Auth, Firestore, Messaging).
3. Implementasikan `AuthRepository`, `HospitalRepository`, `QueueRepository` (`data/repository/Repositories.kt`) dengan Firebase di paket `data/remote`,
   lalu ganti pembuatannya di `ServiceLocator` (`RuangTungguApp.kt`). Pemetaan model→koleksi ada di komentar `Models.kt`.
4. Slot/nomor harus memakai **transaksi Firestore**; aturan keamanan: pengguna hanya boleh membaca/menulis dokumen `queues` miliknya.
5. FCM: kirim dari backend (mis. Cloud Functions) setelah petugas mengubah nomor dilayani; implementasikan `NotificationSender` baru.
   Logika keputusan kirim/ulang (`NotificationPolicy`, `QueueMonitorService`) sudah terpisah dan bisa dipakai ulang di backend.

## Struktur proyek
```
RuangTunggu/
├── app/src/main/java/com/example/ruangtunggu/
│   ├── MainActivity.kt, RuangTungguApp.kt (ServiceLocator)
│   ├── data/model        Models.kt (User, Hospital, Poli, Doctor, Schedule, Queue, ...)
│   ├── data/repository   interface repository, HospitalSearch, QueueMonitorService
│   ├── data/local        AppDatabase (skema+seed), Local*Repository, SessionManager
│   ├── data/remote       NotificationSender (+ implementasi lokal; titik masuk FCM)
│   ├── ui/{auth,home,profile,hospital,schedule,registration,queue,history,common}
│   └── utils             AppConfig, Validators, QueueMath, NotificationPolicy, PasswordHasher, DateUtils
├── app/src/main/res      layout, drawable (vektor + aset dari SVG), values, menu, color
├── app/src/test          LogicTest.kt (unit test logika murni)
├── README.md, TRACEABILITY.md
```
Pemetaan model → kolom tabel: `User→users`, `Hospital→hospitals`, `Poli→polis`, `Doctor→doctors`, `Schedule→schedules`
(`kuotaTotal→kuota_total`, `kuotaTersedia→kuota_tersedia`), `Queue→queues` (`status` ∈ Aktif/Selesai/Batal).
Tambahan: `queue_state` (nomor dilayani & terakhir per poli+tanggal), `notif_log` (satu baris per antrean).

## Aset dari wireframe
Logo dan tiga foto rumah sakit diekstrak dari gambar yang tertanam di SVG (`drawable-nodpi/`), ikon launcher dibuat dari logo.
SVG layar penuh **tidak** dipakai sebagai gambar statis: seluruh formulir, tombol, daftar, status, dan navigasi adalah komponen Android.
Ikon memakai vector drawable; latar gelombang splash digambar ulang sebagai vector (`bg_welcome.xml`).
Teks pada SVG sudah berbentuk path, sehingga teks wireframe dibaca dari hasil render gambar.
Tidak diimplementasikan persis: ilustrasi dekoratif halus (bayangan, ikon unik per poli) dan lock-screen mockup sebagai layar tersendiri
(notifikasi nyata memakai sistem Android).

## Pengujian
**Unit test** (`app/src/test/.../LogicTest.kt`, jalankan dengan `./gradlew test`): validasi NIK/email/HP/kata sandi/tanggal, contoh angka wireframe
(sisa 5, estimasi 25 menit), batas notifikasi, tidak ada notifikasi ganda, coba-ulang, pencarian RS/poli, hash kata sandi.
**Status: ditulis, belum dijalankan.**

**Skenario manual** untuk dicentang di perangkat (belum dijalankan):
- Autentikasi: registrasi valid; data tidak valid; email/NIK ganda ditolak; login benar/salah; CAPTCHA tidak dicentang; lupa sandi (kode benar, salah, kedaluwarsa).
- Profil: tampil; simpan valid tetap ada setelah aplikasi ditutup; NIK `3515123` / HP `0812` ditolak "Data tidak valid".
- Pencarian: "Soedono" ditemukan; "Klinik Mawar" → "Data tidak ditemukan"; RS+poli terbawa ke layar berikutnya.
- Pendaftaran: jadwal tersedia dipilih; Poli Mata hari ini → "Jadwal belum tersedia"; slot penuh dicoret; 2 akun berebut slot 1-kuota → yang kedua "Slot penuh";
  nomor unik; kuota berkurang.
- Pantau: tanpa antrean → "Belum ada antrean aktif"; sisa dihitung dari data; Refresh/Petugas memperbarui tampilan.
- Notifikasi: sisa ≤ 2 memicu satu notifikasi; mode gagal → status coba ulang; tidak ada duplikat.
- Riwayat/pembatalan: tab Aktif/Selesai/Batal; batal aktif berhasil dan kuota +1 sekali; batal ulang / yang sedang dilayani ditolak.

## Keterbatasan yang diketahui
- Akses database dilakukan di main thread (data kecil, versi demo). Untuk produksi pindahkan ke background/coroutine.
- Satu perangkat = satu "backend". Dua perangkat tidak berbagi kuota/antrean.
- Tidak ada pemulihan jika proses lupa-sandi dimatikan di tengah jalan (status disimpan di memori).
- Tidak ada pengujian aksesibilitas atau mode gelap (aplikasi memakai tema terang sesuai wireframe).
