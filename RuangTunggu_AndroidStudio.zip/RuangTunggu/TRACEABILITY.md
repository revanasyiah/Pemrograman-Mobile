# TRACEABILITY — Flowchart ↔ Wireframe ↔ Kode ↔ Skenario uji

Flowchart = `mobile.drawio.pdf` (8 halaman). Wireframe = `Pemrograman Mobile.zip` (36 SVG).
Kolom "Status uji": **statis** = diperiksa lewat analisis/simulasi SQL di luar Android; **belum dijalankan** = skenario ada, belum diuji di emulator/perangkat.
Seluruh path relatif terhadap `app/src/main/` (`J/` = `java/com/example/ruangtunggu/`).

## Halaman 1 — Registrasi & Login

| Proses / keputusan | Wireframe | Implementasi | Skenario uji | Status uji |
|---|---|---|---|---|
| Sudah punya akun? Ya→Login, Tidak→Registrasi | `01. Splashscreen`…`04. Splashscreen 3` | `J/ui/auth/SplashActivity.kt`, `res/layout/activity_splash.xml` | Tombol "Sudah punya akun? Masuk" → Login; "Mulai" di halaman terakhir → Registrasi | belum dijalankan |
| Input data registrasi | `Registrasi`, `Pengisian registrasi` | `J/ui/auth/RegisterActivity.kt`, `res/layout/activity_register.xml` | Isi form valid | belum dijalankan |
| Data valid & email belum terdaftar? | `Pengisian registrasi salah`, `registrasi gagal` | `LocalAuthRepository.register()` (`J/data/local/`), `utils/Validators.kt` | NIK 7 digit → banner "Data tidak valid / email sudah terdaftar"; daftar ulang email yang sama ditolak | unit test Validators ditulis; belum dijalankan |
| Simpan akun ke database + "Registrasi berhasil" | `registrasi berhasil` | `register()` (insert `users`, hash PBKDF2), `J/ui/common/SuccessActivity.kt` | Setelah daftar → layar sukses → "Masuk sekarang" → Login | SQL statis; belum dijalankan |
| Input NIK/email, password, captcha | `Login` | `J/ui/auth/LoginActivity.kt`, `res/layout/activity_login.xml`, `res/layout/view_captcha.xml` | Login dengan NIK; dengan email | belum dijalankan |
| Sesuai? Ya → "Anda berhasil masuk" | `Login berhasil`, `Login berhasil masuk` | `LocalAuthRepository.login()`, `SuccessActivity` (target Main) | Login benar → layar "Login berhasil!" → Beranda | belum dijalankan |
| Tidak → "email/password salah" | `Login gagal` | `LoginActivity.showError()` | Password salah → banner merah + kolom sandi merah, tanpa crash | belum dijalankan |
| Lupa sandi (di luar flowchart, ada di wireframe) | `Lupa sandi`, `verifikasi kode lupa kata sandi`, `Kata sandi berhasil dirubah` | `ForgotPasswordActivity`, `VerifyCodeActivity`, `LocalAuthRepository.requestPasswordReset/verifyResetCode/resetPassword` | Kode benar → sandi baru → login dengan sandi baru; kode salah → "Sisa percobaan" | belum dijalankan (MODE DEMO) |

## Halaman 2 — Profil

| Proses / keputusan | Wireframe | Implementasi | Skenario uji | Status uji |
|---|---|---|---|---|
| Tampilkan data profil pasien | `Profil` | `J/ui/profile/ProfileFragment.kt`, `res/layout/fragment_profile.xml` | Data sesuai akun; NIK & HP tersamar | belum dijalankan |
| Ubah data profil? → form | `Ubah profil benar` | `J/ui/profile/EditProfileActivity.kt`, `activity_edit_profile.xml` | Tombol "Ubah Profil" membuka form terisi | belum dijalankan |
| Data profil valid? Tidak → "Data tidak valid" | `Ubah profil gagal` | `LocalAuthRepository.updateProfile()` | NIK `3515123`, HP `0812` → kolom merah + banner | Validators diuji unit (belum dijalankan) |
| Simpan ke database + "Profil berhasil diperbarui" | `Profil berhasil` | `updateProfile()` (UPDATE `users`), banner di `ProfileFragment` | Simpan → banner hijau; tutup & buka ulang aplikasi → data tetap | belum dijalankan |

## Halaman 3 — Cari RS & Poli

| Proses / keputusan | Wireframe | Implementasi | Skenario uji | Status uji |
|---|---|---|---|---|
| Input kata kunci (nama RS / poli) | `Cari RS & Poli` | `J/ui/hospital/SearchHospitalActivity.kt`, `activity_search_hospital.xml` | Ketik "Soedono", "Anak" | belum dijalankan |
| Cari RS & poli di database | — | `data/repository/HospitalSearch.kt`, `LocalHospitalRepository.allHospitals()` | Filter chip + kata kunci | `HospitalSearchTest` ditulis |
| Hasil ditemukan? Tidak → "Data tidak ditemukan" | `Cari RS gagal` | `SearchHospitalActivity.render()` (empty state + "Hapus pencarian") | "Klinik Mawar" → layar kosong | `HospitalSearchTest.not_found_is_empty` ditulis |
| Tampilkan daftar RS & poli; pilih RS & poli | `Cari RS & Poli`, `Pilih poli`, `Poli terpilih` | `SearchHospitalActivity`, `J/ui/hospital/SelectPoliActivity.kt`, `activity_select_poli.xml` | Pilih RS → poli; RS terbawa ke layar poli, pra-pilih poli dari filter | belum dijalankan |

## Halaman 4 — Dokter & jadwal

| Proses / keputusan | Wireframe | Implementasi | Skenario uji | Status uji |
|---|---|---|---|---|
| Pilih poli → ambil dokter & jadwal | `Pilih jadwal dokter` | `J/ui/schedule/SelectScheduleActivity.kt`, `LocalHospitalRepository.doctorSchedules()` | Poli Anak hari ini: 2–3 dokter, jam 3 slot | SQL statis; belum dijalankan |
| Jadwal tersedia? Tidak → "Jadwal belum tersedia" | (empty state; wireframe tidak punya layar khusus, mengikuti gaya `Cari RS gagal`) | `SelectScheduleActivity.loadDay()` → `emptyState` | Poli Mata hari ini (praktik hari ke-1/3/5) | belum dijalankan |
| Pilih dokter & jadwal | `Pilih jadwal dokter` | slot chip → `SummaryActivity.intent(scheduleId)` | Slot penuh (13:00 dr. Anggita) dicoret & tidak bisa dipilih | belum dijalankan |

## Halaman 5 — Konfirmasi pendaftaran & nomor antrean

| Proses / keputusan | Wireframe | Implementasi | Skenario uji | Status uji |
|---|---|---|---|---|
| Slot antrean tersedia? Tidak → "Slot penuh, pilih jadwal lain" | `Slot penuh` | `J/ui/registration/SummaryActivity.kt` (`showFull`), `register()` → `SlotFull` | Akun A ambil slot 1-kuota; akun B (layar sudah terbuka) konfirmasi → Slot penuh | **simulasi SQL**: pendaftar kedua ditolak; UI belum dijalankan |
| Tampilkan ringkasan | `RIngkasan konfirmasi pendaftaran` | `activity_summary.xml` | Data RS/poli/dokter/tanggal/jam/pasien benar | belum dijalankan |
| Konfirmasi? Tidak → "Pendaftaran dibatalkan" | (dialog gaya `Pembatalan antrean`) | `SummaryActivity.cancelRegistration()` | Tombol "Batal" → dialog → Beranda, kuota tidak berubah | belum dijalankan |
| Terbitkan nomor, simpan antrean, kurangi kuota (atomik) | — | `LocalQueueRepository.register()` — transaksi: `UPDATE … kuota_tersedia-1 WHERE kuota_tersedia>0`, penghitung `queue_state`, `INSERT queues` (UNIQUE poli+tanggal+nomor) | Dua pendaftaran berurutan → A-023, A-024; kuota −1 tiap kali; slot terakhir hanya untuk satu pasien | **simulasi SQL berhasil** (A-023 → slot penuh → A-024) |
| Tampilkan "Nomor antrean A-023" | `Pendaftaran berhasil` | `J/ui/registration/TicketActivity.kt`, `activity_ticket.xml` | Nomor berasal dari database, bukan angka tetap; QR dibuat | belum dijalankan |

## Halaman 6 — Pantau antrean

| Proses / keputusan | Wireframe | Implementasi | Skenario uji | Status uji |
|---|---|---|---|---|
| Buka Pantau Antrean; punya antrean aktif? Tidak → "Belum ada antrean aktif" | `Belum ada antrean aktif` | `J/ui/queue/QueueFragment.kt`, `LocalQueueRepository.monitor()` | Akun baru → state kosong + "Daftar antrean baru" | belum dijalankan |
| Ambil nomor pasien & nomor dilayani; hitung sisa & posisi | `Pantau antrean` | `monitor()`, `utils/QueueMath.kt` | A-023 vs dilayani A-018 → sisa 5, estimasi 25 menit | `QueueMathTest` ditulis |
| Tampilkan status & posisi; Refresh? | `Pantau antrean` | `QueueFragment.refresh()`, tombol "Refresh status" | Petugas (demo) panggil → sisa turun setelah refresh | belum dijalankan |

## Halaman 7 — Notifikasi giliran mendekat

| Proses / keputusan | Wireframe | Implementasi | Skenario uji | Status uji |
|---|---|---|---|---|
| Petugas memperbarui nomor dilayani | — | `LocalQueueRepository.officerCallNext()` + tombol panel MODE DEMO di `QueueFragment` | Tekan tombol; nomor dilayani +1 | SQL statis; belum dijalankan |
| Sistem menghitung sisa antrean tiap pasien | — | `data/repository/QueueMonitorService.evaluateForUser()` | — | belum dijalankan |
| Sisa ≤ batas notifikasi? | `Pantau antrean` ("Notifikasi dikirim saat sisa antrean ≤ 2") | `utils/NotificationPolicy.decide()`, `AppConfig.NOTIF_THRESHOLD = 2` | sisa 3 → tidak; sisa 2 → kirim | `NotificationPolicyTest` ditulis |
| Backend kirim via FCM | — | **Tidak ada FCM.** `data/remote/NotificationSender.kt` (`LocalNotificationSender` = notifikasi lokal MODE DEMO) | — | tidak berlaku (butuh Firebase) |
| Pengiriman berhasil? Tidak → jadwalkan kirim ulang | — | `QueueMonitorService` (RETRY, +30 dtk, maks. 3×, lalu FAILED) ; `notif_log` | Centang "Simulasikan pengiriman gagal" → status RETRY; matikan lalu refresh setelah 30 dtk → terkirim | policy diuji unit (belum dijalankan); retry hanya saat aplikasi dibuka |
| "Giliran Anda sudah dekat" | `Notifikasi` | `LocalNotificationSender.send()`; daftar di ikon lonceng `HomeFragment` | Notifikasi muncul sekali; panggil lagi → tidak duplikat | `NotificationPolicyTest.no_duplicate_after_sent` ditulis |

## Halaman 8 — Riwayat & pembatalan

| Proses / keputusan | Wireframe | Implementasi | Skenario uji | Status uji |
|---|---|---|---|---|
| Buka Riwayat; tampilkan Aktif/Selesai/Batal | `Riwayat antrean` | `J/ui/history/HistoryFragment.kt`, `LocalQueueRepository.history()` (filter `user_id`) | Dua akun: riwayat tidak tercampur | belum dijalankan |
| Ingin membatalkan? Pilih antrean | `Pembatalan antrean` | `HistoryFragment.askCancel()` + `StatusDialog` (konfirmasi) | Tombol "Batalkan" → dialog "Batalkan antrean?" | belum dijalankan |
| Status masih aktif? Tidak → "Antrean tidak dapat dibatalkan" | `Pembatalan gagal` | `LocalQueueRepository.cancel()` → `NotActive` | Batalkan antrean Selesai/Batal/sedang dilayani → ditolak | **simulasi SQL**: pembatalan kedua = 0 baris berubah |
| Ubah status jadi Batal & kembalikan kuota | — | `cancel()` — `UPDATE … WHERE status='Aktif'` (hanya satu yang lolos) lalu `kuota_tersedia+1` dalam satu transaksi | Kuota naik tepat 1; tombol ditekan berulang tidak menggandakan | **simulasi SQL berhasil** (kuota 0→1, batal ulang tidak mengubah) |
| "Antrean berhasil dibatalkan" | `Pembatalan berhasil` | `StatusDialog` SUCCESS | Dialog hijau → "Selesai" → daftar diperbarui | belum dijalankan |

## Navigasi umum

| Alur | Implementasi |
|---|---|
| Splash → Login/Registrasi → Beranda | `SplashActivity` (cek sesi), `LoginActivity`, `SuccessActivity` → `MainActivity` |
| Beranda → Cari RS → Poli → Jadwal → Ringkasan → Tiket → Pantau | `HomeFragment` → `SearchHospitalActivity` → `SelectPoliActivity` → `SelectScheduleActivity` → `SummaryActivity` → `TicketActivity` → `MainActivity(TAB_QUEUE)` |
| Konteks pendaftaran | Id (`hospitalId`, `poliId`, `scheduleId`) lewat Intent; detail selalu dibaca ulang dari database (satu sumber data) |
| Back | Tiket → Beranda; tab selain Beranda → Beranda; layar lain kembali satu langkah |
