package com.example.ruangtunggu.ui.common

import android.app.Dialog
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.core.view.isVisible
import com.example.ruangtunggu.R
import com.example.ruangtunggu.data.model.QueueStatus
import com.example.ruangtunggu.databinding.DialogStatusBinding
import com.example.ruangtunggu.databinding.ViewHeaderBinding

fun View.show(visible: Boolean) { isVisible = visible }

/** Mengisi header bersama (judul, subjudul, tombol kembali). [onBack] null = tombol kembali disembunyikan. */
fun ViewHeaderBinding.bind(title: String, subtitle: String, onBack: (() -> Unit)?) {
    headerTitle.text = title
    headerSubtitle.text = subtitle
    btnBack.isVisible = onBack != null
    if (onBack != null) btnBack.setOnClickListener { onBack() }
}

fun TextView.applyStatusBadge(status: String) {
    text = status
    when (status) {
        QueueStatus.AKTIF -> { setBackgroundResource(R.drawable.bg_badge_active); setTextColor(ContextCompat.getColor(context, R.color.teal_900)) }
        QueueStatus.SELESAI -> { setBackgroundResource(R.drawable.bg_badge_done); setTextColor(ContextCompat.getColor(context, R.color.slate_600)) }
        else -> { setBackgroundResource(R.drawable.bg_badge_cancel); setTextColor(ContextCompat.getColor(context, R.color.danger)) }
    }
}

/** Resolusi nama aset foto RS (dari data) ke drawable; null jika tidak ada foto. */
fun hospitalPhoto(name: String?): Int? = when (name) {
    "rs_soedono" -> R.drawable.rs_soedono
    "rs_harapan_bunda" -> R.drawable.rs_harapan_bunda
    "rs_medika" -> R.drawable.rs_medika
    else -> null
}

enum class DialogKind { WARNING, SUCCESS, ERROR }

/**
 * Dialog dengan overlay sesuai wireframe (Pembatalan antrean / berhasil / gagal).
 * - [negative] null => hanya satu tombol.
 * - [danger] true => tombol positif merah ("Ya, batalkan").
 * - [positiveOutline] true => tombol tunggal berbentuk outline ("Mengerti").
 */
object StatusDialog {
    fun show(
        context: Context,
        kind: DialogKind,
        title: String,
        message: String,
        positive: String,
        negative: String? = null,
        danger: Boolean = false,
        positiveOutline: Boolean = false,
        cancelable: Boolean = true,
        onPositive: (() -> Unit)? = null,
        onNegative: (() -> Unit)? = null
    ): Dialog {
        val b = DialogStatusBinding.inflate(android.view.LayoutInflater.from(context))
        val dialog = Dialog(context)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setContentView(b.root)
        dialog.window?.apply {
            setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            setLayout((context.resources.displayMetrics.widthPixels * 0.88).toInt(), ViewGroup.LayoutParams.WRAP_CONTENT)
            setDimAmount(0.55f)
        }
        dialog.setCancelable(cancelable)

        val (bgColor, iconRes, tint) = when (kind) {
            DialogKind.WARNING -> Triple(R.color.danger_soft, R.drawable.ic_error, R.color.danger)
            DialogKind.ERROR -> Triple(R.color.danger_soft, R.drawable.ic_close, R.color.danger)
            DialogKind.SUCCESS -> Triple(R.color.success_bg, R.drawable.ic_check, R.color.success)
        }
        b.dialogIconBg.setBackgroundResource(R.drawable.bg_circle_100)
        b.dialogIconBg.background.mutate().setTint(ContextCompat.getColor(context, bgColor))
        b.dialogIcon.setImageResource(iconRes)
        b.dialogIcon.setColorFilter(ContextCompat.getColor(context, tint))
        b.dialogTitle.text = title
        b.dialogMessage.text = message

        // Tombol: negatif (outline) + positif (isi teal) atau bahaya (isi merah)
        b.dialogNegative.isVisible = negative != null
        b.dialogNegative.text = negative
        b.dialogNegative.setOnClickListener { dialog.dismiss(); onNegative?.invoke() }
        val main = if (danger) b.dialogDanger else b.dialogPositive
        b.dialogPositive.isVisible = !danger
        b.dialogDanger.isVisible = danger
        main.text = positive
        main.setOnClickListener {
            main.isEnabled = false // cegah ketukan berulang
            dialog.dismiss()
            onPositive?.invoke()
        }
        if (positiveOutline && negative == null) {
            // Satu tombol outline: gunakan tombol negatif sebagai tombol tunggal
            b.dialogNegative.isVisible = true
            b.dialogNegative.text = positive
            b.dialogNegative.setOnClickListener { dialog.dismiss(); onPositive?.invoke() }
            b.dialogPositive.isVisible = false
            b.dialogDanger.isVisible = false
        }
        dialog.show()
        return dialog
    }
}
