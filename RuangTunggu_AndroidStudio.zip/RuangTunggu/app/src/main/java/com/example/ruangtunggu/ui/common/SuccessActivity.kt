package com.example.ruangtunggu.ui.common

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.example.ruangtunggu.MainActivity
import com.example.ruangtunggu.R
import com.example.ruangtunggu.databinding.ActivitySuccessBinding
import com.example.ruangtunggu.ui.auth.LoginActivity

/** Layar sukses generik: Registrasi berhasil, Login berhasil, Kata sandi berhasil diubah. */
class SuccessActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val b = ActivitySuccessBinding.inflate(layoutInflater)
        setContentView(b.root)

        b.successTitle.text = intent.getStringExtra(EXTRA_TITLE).orEmpty()
        b.successSubtitle.text = intent.getStringExtra(EXTRA_SUBTITLE).orEmpty()
        b.btnSuccess.text = intent.getStringExtra(EXTRA_BUTTON).orEmpty()

        val labels = intent.getStringArrayExtra(EXTRA_LABELS) ?: emptyArray()
        val values = intent.getStringArrayExtra(EXTRA_VALUES) ?: emptyArray()
        b.successRows.visibility = if (labels.isEmpty()) View.GONE else View.VISIBLE
        labels.forEachIndexed { i, label ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                setPadding(0, if (i == 0) 0 else dp(10), 0, 0)
            }
            row.addView(TextView(this).apply {
                text = label; textSize = 12f; setTextColor(ContextCompat.getColor(context, R.color.slate_500))
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            })
            row.addView(TextView(this).apply {
                text = values.getOrElse(i) { "" }; textSize = 13f; setTextColor(ContextCompat.getColor(context, R.color.ink))
                setTypeface(typeface, android.graphics.Typeface.BOLD)
            })
            b.successRows.addView(row)
        }

        val target = intent.getStringExtra(EXTRA_TARGET)
        b.btnSuccess.setOnClickListener {
            val next = if (target == TARGET_MAIN) Intent(this, MainActivity::class.java) else Intent(this, LoginActivity::class.java)
            startActivity(next.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK))
            finish()
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    companion object {
        const val EXTRA_TITLE = "title"
        const val EXTRA_SUBTITLE = "subtitle"
        const val EXTRA_BUTTON = "button"
        const val EXTRA_LABELS = "labels"
        const val EXTRA_VALUES = "values"
        const val EXTRA_TARGET = "target"
        const val TARGET_MAIN = "main"
        const val TARGET_LOGIN = "login"

        fun intent(
            ctx: Context, title: String, subtitle: String, button: String, target: String,
            rows: List<Pair<String, String>> = emptyList()
        ): Intent = Intent(ctx, SuccessActivity::class.java)
            .putExtra(EXTRA_TITLE, title).putExtra(EXTRA_SUBTITLE, subtitle).putExtra(EXTRA_BUTTON, button)
            .putExtra(EXTRA_TARGET, target)
            .putExtra(EXTRA_LABELS, rows.map { it.first }.toTypedArray())
            .putExtra(EXTRA_VALUES, rows.map { it.second }.toTypedArray())
    }
}
