package com.example.ruangtunggu.data.local

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import com.example.ruangtunggu.utils.AppConfig
import java.time.LocalDate

/**
 * Penyimpanan persisten (SQLite). Dipilih agar project bisa dibuild tanpa plugin tambahan (kapt/ksp).
 * Semua data rumah sakit/dokter/jadwal di sini adalah DATA DEMO FIKTIF.
 */
class AppDatabase private constructor(ctx: Context) :
    SQLiteOpenHelper(ctx.applicationContext, "ruangtunggu.db", null, 1) {

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            """CREATE TABLE users(
                user_id INTEGER PRIMARY KEY AUTOINCREMENT,
                nama TEXT NOT NULL,
                email TEXT UNIQUE,
                nomor_hp TEXT UNIQUE,
                nik TEXT NOT NULL UNIQUE,
                tempat_lahir TEXT NOT NULL,
                tanggal_lahir TEXT NOT NULL,
                jenis_kelamin TEXT,
                pass_hash TEXT NOT NULL,
                pass_salt TEXT NOT NULL)"""
        )
        db.execSQL(
            """CREATE TABLE hospitals(
                hospital_id INTEGER PRIMARY KEY, nama TEXT NOT NULL, alamat TEXT NOT NULL, kontak TEXT NOT NULL,
                rating REAL NOT NULL, jarak_km REAL NOT NULL, jam_buka TEXT NOT NULL, foto TEXT)"""
        )
        db.execSQL(
            """CREATE TABLE polis(
                poli_id INTEGER PRIMARY KEY, hospital_id INTEGER NOT NULL, nama_poli TEXT NOT NULL, kode TEXT NOT NULL)"""
        )
        db.execSQL(
            """CREATE TABLE doctors(
                doctor_id INTEGER PRIMARY KEY, poli_id INTEGER NOT NULL, nama TEXT NOT NULL, spesialis TEXT NOT NULL,
                rating REAL NOT NULL, pengalaman INTEGER NOT NULL, pola INTEGER NOT NULL)"""
        )
        db.execSQL(
            """CREATE TABLE schedules(
                schedule_id INTEGER PRIMARY KEY AUTOINCREMENT, doctor_id INTEGER NOT NULL, tanggal TEXT NOT NULL,
                jam_mulai TEXT NOT NULL, jam_selesai TEXT NOT NULL, kuota_total INTEGER NOT NULL, kuota_tersedia INTEGER NOT NULL,
                CHECK(kuota_tersedia >= 0 AND kuota_tersedia <= kuota_total))"""
        )
        db.execSQL("CREATE UNIQUE INDEX idx_schedule_slot ON schedules(doctor_id, tanggal, jam_mulai)")
        // Penghitung antrean per poli per tanggal (nomor sedang dilayani + nomor terakhir yang diterbitkan)
        db.execSQL(
            """CREATE TABLE queue_state(
                poli_id INTEGER NOT NULL, tanggal TEXT NOT NULL, last_issued INTEGER NOT NULL, serving INTEGER NOT NULL,
                PRIMARY KEY(poli_id, tanggal))"""
        )
        db.execSQL(
            """CREATE TABLE queues(
                queue_id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL, hospital_id INTEGER NOT NULL,
                poli_id INTEGER NOT NULL, doctor_id INTEGER NOT NULL, schedule_id INTEGER NOT NULL,
                queue_number INTEGER NOT NULL, queue_code TEXT NOT NULL, tanggal TEXT NOT NULL,
                status TEXT NOT NULL, created_at INTEGER NOT NULL,
                UNIQUE(poli_id, tanggal, queue_number))"""
        )
        db.execSQL("CREATE INDEX idx_queue_user ON queues(user_id, status)")
        db.execSQL(
            """CREATE TABLE notif_log(
                queue_id INTEGER PRIMARY KEY, status TEXT NOT NULL, attempts INTEGER NOT NULL,
                next_retry_at INTEGER NOT NULL, message TEXT NOT NULL, sisa INTEGER NOT NULL,
                created_at INTEGER NOT NULL, sent_at INTEGER)"""
        )
        seed(db)
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        // Versi demo: bangun ulang. Untuk produksi gunakan migrasi.
        for (t in listOf("notif_log", "queues", "queue_state", "schedules", "doctors", "polis", "hospitals", "users")) {
            db.execSQL("DROP TABLE IF EXISTS $t")
        }
        onCreate(db)
    }

    // ---------------------------------------------------------------- seed data (demo)

    private class PoliDef(val nama: String, val kode: String, val spesialis: String, val dokter: List<String>)

    private val poliDefs = listOf(
        PoliDef("Umum", "B", "Dokter Umum", listOf("dr. Budi Santoso", "dr. Citra Lestari", "dr. Dewi Anjani")),
        PoliDef("Anak", "A", "Dokter Spesialis Anak", listOf("dr. Anggita, Sp.A", "dr. Abdul Farid, Sp.A", "dr. Rina Kusuma, Sp.A")),
        PoliDef("Gigi", "C", "Dokter Gigi", listOf("drg. Eka Putri", "drg. Fajar Nugroho")),
        PoliDef("Kandungan", "D", "Dokter Spesialis Kandungan", listOf("dr. Gita Maharani, Sp.OG", "dr. Hendra Wijaya, Sp.OG")),
        PoliDef("Mata", "E", "Dokter Spesialis Mata", listOf("dr. Indah Permata, Sp.M", "dr. Joko Prasetyo, Sp.M")),
        PoliDef("Penyakit Dalam", "F", "Dokter Spesialis Penyakit Dalam", listOf("dr. Kartika Sari, Sp.PD", "dr. Lukman Hakim, Sp.PD"))
    )

    private fun seed(db: SQLiteDatabase) {
        data class H(val id: Long, val nama: String, val alamat: String, val rating: Double, val jarak: Double, val foto: String?, val polis: List<String>)

        val all = listOf("Umum", "Anak", "Gigi", "Kandungan", "Mata", "Penyakit Dalam")
        val basic = listOf("Anak", "Umum", "Gigi")
        val hospitals = listOf(
            H(1, "RS Sehat Sidoarjo", "Jl. Contoh No. 1, Sidoarjo", 4.8, 1.2, null, all),
            H(2, "RS Soedono", "Jl. Contoh No. 2, Kota Demo", 4.8, 1.2, "rs_soedono", basic),
            H(3, "RS Harapan Bunda", "Jl. Contoh No. 3, Kota Demo", 4.8, 1.2, "rs_harapan_bunda", basic),
            H(4, "RS Medika", "Jl. Contoh No. 4, Kota Demo", 4.8, 1.2, "rs_medika", basic)
        )
        var poliId = 0L
        var doctorId = 0L
        for (h in hospitals) {
            db.insert("hospitals", null, ContentValues().apply {
                put("hospital_id", h.id); put("nama", h.nama); put("alamat", h.alamat)
                put("kontak", "(000) 000-000 (demo)"); put("rating", h.rating); put("jarak_km", h.jarak)
                put("jam_buka", "Buka 24 jam"); put("foto", h.foto)
            })
            for (pn in h.polis) {
                val def = poliDefs.first { it.nama == pn }
                poliId++
                db.insert("polis", null, ContentValues().apply {
                    put("poli_id", poliId); put("hospital_id", h.id); put("nama_poli", def.nama); put("kode", def.kode)
                })
                val take = if (h.polis.size == 6) def.dokter.size else minOf(2, def.dokter.size)
                for (k in 0 until take) {
                    doctorId++
                    db.insert("doctors", null, ContentValues().apply {
                        put("doctor_id", doctorId); put("poli_id", poliId); put("nama", def.dokter[k])
                        put("spesialis", def.spesialis); put("rating", 4.5 + (k % 5) / 10.0)
                        put("pengalaman", 8 + k * 6); put("pola", k)
                    })
                }
            }
        }
    }

    /**
     * Membuat jadwal [AppConfig.SCHEDULE_DAYS] hari ke depan (idempoten berkat UNIQUE INDEX).
     * Poli Mata sengaja hanya praktik di hari ke-1, 3, 5 sehingga kondisi "Jadwal belum tersedia" dapat diuji.
     * Beberapa slot hari ini diset khusus agar sesuai wireframe (kuota 12, penuh, dan kuota 1 untuk uji slot terakhir).
     */
    fun ensureSchedules(today: LocalDate = LocalDate.now()) {
        val templates = listOf(
            listOf("09:00", "10:30", "13:00"),
            listOf("08:00", "11:00", "14:00"),
            listOf("10:00", "12:30", "15:00")
        )
        val db = writableDatabase
        db.beginTransaction()
        try {
            val docs = ArrayList<Triple<Long, String, Int>>() // doctorId, poliNama, pola
            db.rawQuery(
                "SELECT d.doctor_id, p.nama_poli, d.pola, d.nama FROM doctors d JOIN polis p ON p.poli_id=d.poli_id", null
            ).use { c ->
                val names = HashMap<Long, String>()
                while (c.moveToNext()) {
                    docs.add(Triple(c.getLong(0), c.getString(1), c.getInt(2)))
                    names[c.getLong(0)] = c.getString(3)
                }
                for ((id, poli, pola) in docs) {
                    val offsets = if (poli == "Mata") listOf(1, 3, 5) else (0 until AppConfig.SCHEDULE_DAYS).toList()
                    for (off in offsets) {
                        if (off >= AppConfig.SCHEDULE_DAYS) continue
                        val tgl = today.plusDays(off.toLong()).toString()
                        for (jam in templates[pola % templates.size]) {
                            var quota = AppConfig.DEFAULT_QUOTA
                            val n = names[id].orEmpty()
                            if (off == 0 && n.startsWith("dr. Anggita") && jam == "09:00") quota = 12
                            if (off == 0 && n.startsWith("dr. Anggita") && jam == "13:00") quota = 0
                            if (off == 0 && n.startsWith("dr. Abdul Farid") && jam == "11:00") quota = 1
                            val (h, m) = jam.split(":").map { it.toInt() }
                            val end = "%02d:%02d".format((h * 60 + m + 60) / 60 % 24, (h * 60 + m + 60) % 60)
                            db.insertWithOnConflict("schedules", null, ContentValues().apply {
                                put("doctor_id", id); put("tanggal", tgl); put("jam_mulai", jam); put("jam_selesai", end)
                                put("kuota_total", AppConfig.DEFAULT_QUOTA); put("kuota_tersedia", quota)
                            }, SQLiteDatabase.CONFLICT_IGNORE)
                        }
                    }
                }
            }
            db.setTransactionSuccessful()
        } finally {
            db.endTransaction()
        }
    }

    companion object {
        @Volatile
        private var instance: AppDatabase? = null

        fun get(ctx: Context): AppDatabase =
            instance ?: synchronized(this) { instance ?: AppDatabase(ctx).also { instance = it } }
    }
}
