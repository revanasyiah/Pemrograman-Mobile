package com.example.ruangtunggu.ui.registration

import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.example.ruangtunggu.MainActivity
import com.example.ruangtunggu.R
import com.example.ruangtunggu.ServiceLocator
import com.example.ruangtunggu.data.model.ScheduleDetail
import com.example.ruangtunggu.data.repository.RegisterQueueResult
import com.example.ruangtunggu.databinding.ActivitySummaryBinding
import com.example.ruangtunggu.ui.common.DialogKind
import com.example.ruangtunggu.ui.common.StatusDialog
import com.example.ruangtunggu.ui.common.bind
import com.example.ruangtunggu.ui.common.show
import com.example.ruangtunggu.utils.DateUtils
import com.example.ruangtunggu.utils.Validators

/**
 * Ringkasan & Konfirmasi (flowchart hal. 5):
 * slot tersedia? -> ringkasan -> konfirmasi? -> terbitkan nomor, simpan, kurangi kuota -> nomor antrean.
 * Pemeriksaan slot dilakukan lagi secara atomik di repository saat konfirmasi.
 */
class SummaryActivity : AppCompatActivity() {

    private lateinit var b: ActivitySummaryBinding
    private lateinit var detail: ScheduleDetail
    private var scheduleId = -1L
    private var processing = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivitySummaryBinding.inflate(layoutInflater)
        setContentView(b.root)
        b.header.bind("Ringkasan Pendaftaran", "Periksa kembali data Anda") { finish() }

        scheduleId = intent.getLongExtra(EXTRA_SCHEDULE_ID, -1)
        val user = ServiceLocator.auth.currentUser()
        val d = ServiceLocator.hospitals.scheduleDetail(scheduleId)
        if (user == null || d == null) { finish(); return }
        detail = d

        b.tvHospital.text = d.hospital.nama
        b.tvAddress.text = d.hospital.alamat
        b.tvPoli.text = d.poli.namaPoli
        b.tvDoctor.text = d.doctor.nama
        b.tvDate.text = DateUtils.fullLabel(d.schedule.tanggal)
        b.tvTime.text = "${d.schedule.jamMulai} WIB"
        b.tvAvatar.text = DateUtils.initials(user.nama)
        b.tvPatient.text = user.nama
        b.tvPatientNik.text = "NIK " + Validators.maskNik(user.nik)

        b.btnCancel.setOnClickListener { cancelRegistration() }
        b.btnConfirm.setOnClickListener { onPrimary() }
        refreshSlotInfo()
    }

    /** Ambil kuota terbaru dari database dan tampilkan kondisi tersedia / penuh. */
    private fun refreshSlotInfo() {
        val latest = ServiceLocator.hospitals.scheduleDetail(scheduleId)?.schedule ?: return
        showFull(latest.penuh, latest.kuotaTersedia)
    }

    private var full = false

    private fun showFull(isFull: Boolean, quota: Int) {
        full = isFull
        b.badgeFull.show(isFull)
        if (isFull) {
            b.quotaCard.setBackgroundResource(R.drawable.bg_banner_error)
            b.quotaIcon.setImageResource(R.drawable.ic_error)
            b.quotaIcon.setColorFilter(ContextCompat.getColor(this, R.color.danger))
            b.quotaTitle.text = "Slot penuh"
            b.quotaTitle.setTextColor(ContextCompat.getColor(this, R.color.danger))
            b.quotaDesc.text = "Slot penuh, pilih jadwal lain.\nKuota jadwal ini sudah habis."
            b.btnConfirm.text = "Pilih jadwal lain"
        } else {
            b.quotaCard.setBackgroundResource(R.drawable.bg_banner_info)
            b.quotaIcon.setImageResource(R.drawable.ic_check_circle)
            b.quotaIcon.setColorFilter(ContextCompat.getColor(this, R.color.primary))
            b.quotaTitle.text = "Kuota tersedia"
            b.quotaTitle.setTextColor(ContextCompat.getColor(this, R.color.teal_900))
            b.quotaDesc.text = "Kuota tersisa $quota slot untuk jadwal ini.\nKonfirmasi sekarang agar tidak terlewat."
            b.btnConfirm.text = "Konfirmasi pendaftaran"
        }
    }

    private fun onPrimary() {
        if (full) { finish(); return } // kembali ke pilihan jadwal
        confirm()
    }

    private fun confirm() {
        if (processing) return
        processing = true
        b.btnConfirm.isEnabled = false
        try {
            val user = ServiceLocator.auth.currentUser() ?: return
            when (val r = ServiceLocator.queues.register(user.userId, scheduleId)) {
                is RegisterQueueResult.Success -> {
                    // Antrean baru dapat langsung memicu pemeriksaan notifikasi
                    ServiceLocator.monitor.evaluateForUser(user.userId)
                    startActivity(TicketActivity.intent(this, r.detail.queue.queueId, detailMode = false))
                    finish()
                }
                RegisterQueueResult.SlotFull -> {
                    refreshSlotInfo()
                    showFull(true, 0)
                }
                is RegisterQueueResult.Duplicate -> StatusDialog.show(
                    this, DialogKind.WARNING, "Antrean sudah ada",
                    "Anda sudah memiliki antrean aktif pada jadwal ini (${r.detail.queue.queueCode}).",
                    positive = "Lihat antrean", negative = "Tutup",
                    onPositive = { startActivity(TicketActivity.intent(this, r.detail.queue.queueId, detailMode = true)) }
                )
                RegisterQueueResult.NotFound -> finish()
            }
        } finally {
            processing = false
            b.btnConfirm.isEnabled = true
        }
    }

    private fun cancelRegistration() {
        StatusDialog.show(
            this, DialogKind.WARNING, "Pendaftaran dibatalkan",
            "Anda belum mendapatkan nomor antrean. Tidak ada kuota yang terpakai.",
            positive = "Kembali ke beranda", cancelable = false,
            onPositive = {
                startActivity(Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK))
                finish()
            }
        )
    }

    companion object {
        const val EXTRA_SCHEDULE_ID = "schedule_id"
        fun intent(ctx: Context, scheduleId: Long): Intent = Intent(ctx, SummaryActivity::class.java).putExtra(EXTRA_SCHEDULE_ID, scheduleId)
    }
}
