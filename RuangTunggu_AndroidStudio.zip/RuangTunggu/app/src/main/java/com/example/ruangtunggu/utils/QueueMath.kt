package com.example.ruangtunggu.utils

/** Perhitungan antrean murni (flowchart hal. 6 dan 7). */
object QueueMath {
    /** Sisa antrean = nomor pasien - nomor yang sedang dilayani (minimal 0). */
    fun sisa(myNumber: Int, serving: Int): Int = maxOf(0, myNumber - serving)

    fun estimasiMenit(sisa: Int): Int = sisa * AppConfig.MINUTES_PER_PATIENT

    fun shouldNotify(sisa: Int, threshold: Int = AppConfig.NOTIF_THRESHOLD): Boolean = sisa <= threshold

    fun code(prefix: String, number: Int) = "$prefix-%03d".format(number)

    /** Nomor-nomor setelah yang sedang dilayani sampai nomor pasien (maks. [limit] terakhir). */
    fun upcoming(myNumber: Int, serving: Int, limit: Int = 5): List<Int> {
        val from = maxOf(serving + 1, myNumber - limit + 1)
        return if (from > myNumber) emptyList() else (from..myNumber).toList()
    }

    /** Kemajuan antrean 0..100 untuk indikator progres (dari saat daftar sampai giliran tiba). */
    fun progress(myNumber: Int, serving: Int): Int {
        val total = maxOf(1, myNumber - AppConfig.INITIAL_SERVING)
        val done = (total - sisa(myNumber, serving)).coerceIn(0, total)
        return done * 100 / total
    }
}
