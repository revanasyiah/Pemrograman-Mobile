package com.example.ruangtunggu.ui.hospital

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.ruangtunggu.R
import com.example.ruangtunggu.ServiceLocator
import com.example.ruangtunggu.data.model.Poli
import com.example.ruangtunggu.databinding.ActivitySelectPoliBinding
import com.example.ruangtunggu.databinding.ItemPoliBinding
import com.example.ruangtunggu.ui.common.bind
import com.example.ruangtunggu.ui.schedule.SelectScheduleActivity
import java.util.Locale

/**
 * Pilih Poli (wireframe Pilih poli / Poli terpilih). Rumah sakit dibawa lewat extra sehingga pengguna tidak
 * perlu memilih ulang. Pilihan poli diteruskan ke layar jadwal lewat id (sumber data = database).
 */
class SelectPoliActivity : AppCompatActivity() {

    private lateinit var b: ActivitySelectPoliBinding
    private var selectedPoliId = -1L
    private lateinit var adapter: PoliAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivitySelectPoliBinding.inflate(layoutInflater)
        setContentView(b.root)
        b.header.bind("Pilih Poli", "Langkah 2 dari 3") { finish() }

        val hospitalId = intent.getLongExtra(EXTRA_HOSPITAL_ID, -1)
        val hospital = ServiceLocator.hospitals.getHospital(hospitalId)
        if (hospital == null) { finish(); return }
        b.tvHospital.text = hospital.nama
        b.tvHospitalMeta.text = "★ %.1f · %.1f km · %s".format(Locale.US, hospital.rating, hospital.jarakKm, hospital.jamBuka)
        b.btnChange.setOnClickListener { finish() } // kembali ke pencarian untuk mengganti RS

        val polis = ServiceLocator.hospitals.polisOf(hospitalId)
        b.tvPoliCount.text = "${polis.size} poli"

        // Pra-pilih poli bila datang dari pencarian/filter poli
        val hint = intent.getStringExtra(EXTRA_HINT).orEmpty().trim()
        if (savedInstanceState == null && hint.isNotEmpty()) {
            polis.firstOrNull { it.namaPoli.contains(hint, true) || it.label.contains(hint, true) }?.let { selectedPoliId = it.poliId }
        } else if (savedInstanceState != null) {
            selectedPoliId = savedInstanceState.getLong(STATE_POLI, -1)
        }

        adapter = PoliAdapter(polis) { selectedPoliId = it; render() }
        b.rvPoli.layoutManager = LinearLayoutManager(this)
        b.rvPoli.adapter = adapter
        b.btnNext.setOnClickListener {
            if (selectedPoliId > 0) startActivity(SelectScheduleActivity.intent(this, selectedPoliId))
        }
        render()
    }

    private fun render() {
        adapter.selected = selectedPoliId
        adapter.notifyDataSetChanged()
        b.btnNext.isEnabled = selectedPoliId > 0
        b.btnNext.text = if (selectedPoliId > 0) "Lanjut pilih dokter" else "Pilih poli terlebih dahulu"
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putLong(STATE_POLI, selectedPoliId)
    }

    companion object {
        const val EXTRA_HOSPITAL_ID = "hospital_id"
        const val EXTRA_HINT = "hint"
        private const val STATE_POLI = "poli_id"
        fun intent(ctx: Context, hospitalId: Long, hint: String? = null): Intent =
            Intent(ctx, SelectPoliActivity::class.java).putExtra(EXTRA_HOSPITAL_ID, hospitalId).putExtra(EXTRA_HINT, hint)
    }
}

class PoliAdapter(private val items: List<Poli>, private val onSelect: (Long) -> Unit) : RecyclerView.Adapter<PoliAdapter.VH>() {
    var selected = -1L

    class VH(val b: ItemPoliBinding) : RecyclerView.ViewHolder(b.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        VH(ItemPoliBinding.inflate(LayoutInflater.from(parent.context), parent, false))

    override fun getItemCount() = items.size

    private fun iconFor(name: String) = when (name) {
        "Umum" -> R.drawable.ic_person
        "Anak", "Kandungan" -> R.drawable.ic_heart
        "Gigi" -> R.drawable.ic_add_box
        "Mata" -> R.drawable.ic_search
        else -> R.drawable.ic_history
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val p = items[position]
        val b = holder.b
        b.imgIcon.setImageResource(iconFor(p.namaPoli))
        b.tvPoli.text = p.label
        b.tvPoliInfo.text = if (p.mulai != null) "${p.jumlahDokter} dokter · mulai ${p.mulai.replace(':', '.')}" else "${p.jumlahDokter} dokter · jadwal belum tersedia"
        val sel = p.poliId == selected
        b.cardRoot.setBackgroundResource(if (sel) R.drawable.bg_card_selected else R.drawable.bg_card)
        b.imgRadio.isSelected = sel
        b.imgRadio.setImageResource(if (sel) R.drawable.ic_check else 0)
        b.cardRoot.setOnClickListener { onSelect(p.poliId) }
    }
}
