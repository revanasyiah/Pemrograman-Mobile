package com.example.ruangtunggu.utils

import java.time.LocalDate

/** Fungsi validasi murni (tanpa dependensi Android) agar mudah diuji. */
object Validators {
    private val EMAIL = Regex("^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$")
    private val DATE = Regex("^(\\d{1,2})/(\\d{1,2})/(\\d{4})$")

    fun isEmail(s: String) = EMAIL.matches(s.trim())

    /** Ubah +62.../62... menjadi 08... dan buang spasi/strip. */
    fun normalizePhone(s: String): String {
        var d = s.filter { it.isDigit() || it == '+' }
        if (d.startsWith("+62")) d = "0" + d.substring(3)
        else if (d.startsWith("62")) d = "0" + d.substring(2)
        return d
    }

    fun isPhone(s: String): Boolean {
        val n = normalizePhone(s)
        return n.length in 10..13 && n.all { it.isDigit() } && n.startsWith("08")
    }

    fun isNik(s: String) = s.length == 16 && s.all { it.isDigit() } && s[0] != '0'

    fun isValidName(s: String) = s.trim().length >= 3 && s.any { it.isLetter() }

    /** Minimal 8 karakter, memuat huruf dan angka. */
    fun isStrongPassword(s: String) = s.length >= 8 && s.any { it.isLetter() } && s.any { it.isDigit() }

    /** "dd/MM/yyyy" -> ISO "yyyy-MM-dd"; null jika tidak valid, di masa depan, atau sebelum 1900. */
    fun parseDate(s: String, today: LocalDate = LocalDate.now()): String? {
        val m = DATE.matchEntire(s.trim()) ?: return null
        return try {
            val d = LocalDate.of(m.groupValues[3].toInt(), m.groupValues[2].toInt(), m.groupValues[1].toInt())
            if (d.isAfter(today) || d.year < 1900) null else d.toString()
        } catch (e: Exception) { null }
    }

    /** "Madiun, 20/04/2005" -> Pair("Madiun", "2005-04-20"); null jika format salah. */
    fun parseBirth(s: String): Pair<String, String>? {
        val idx = s.lastIndexOf(',')
        if (idx <= 0) return null
        val place = s.substring(0, idx).trim()
        val iso = parseDate(s.substring(idx + 1)) ?: return null
        return if (place.length >= 2) place to iso else null
    }

    fun isoToInput(iso: String): String = try {
        val d = LocalDate.parse(iso); "%02d/%02d/%04d".format(d.dayOfMonth, d.monthValue, d.year)
    } catch (e: Exception) { iso }

    fun maskNik(nik: String, ch: Char = '•'): String =
        if (nik.length <= 4) nik else nik.take(4) + ch.toString().repeat(nik.length - 4)

    fun maskPhone(p: String, ch: Char = 'x'): String =
        if (p.length <= 2) p else p.take(2) + ch.toString().repeat(p.length - 2)

    fun maskContact(c: String): String {
        val at = c.indexOf('@')
        return if (at > 2) c.take(2) + "***" + c.substring(at) else maskPhone(c, '*')
    }
}
