package com.example.ruangtunggu.ui.auth

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.ruangtunggu.ServiceLocator
import com.example.ruangtunggu.data.repository.LoginResult
import com.example.ruangtunggu.databinding.ActivityLoginBinding
import com.example.ruangtunggu.ui.common.InputState
import com.example.ruangtunggu.ui.common.SuccessActivity
import com.example.ruangtunggu.ui.common.show
import com.example.ruangtunggu.utils.Validators

/**
 * Login (flowchart hal. 1). Identitas = "NIK / Email" sesuai wireframe Login.svg:
 * flowchart menulis NIK, pesan galat menulis email/password; kolom ini menerima keduanya.
 */
class LoginActivity : AppCompatActivity() {

    private lateinit var b: ActivityLoginBinding
    private var busy = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(b.root)

        b.btnLogin.setOnClickListener { doLogin() }
        b.btnForgot.setOnClickListener { startActivity(Intent(this, ForgotPasswordActivity::class.java)) }
        b.btnRegister.setOnClickListener { startActivity(Intent(this, RegisterActivity::class.java)) }
    }

    private fun showError(msg: String, passwordError: Boolean = false) {
        b.banner.bannerText.text = msg
        b.banner.root.show(true)
        b.inPassword.setState(if (passwordError) InputState.ERROR else InputState.NORMAL)
    }

    private fun doLogin() {
        if (busy) return
        b.banner.root.show(false)
        b.inIdentity.setState(InputState.NORMAL)
        b.inPassword.setState(InputState.NORMAL)
        busy = true
        try {
            val result = ServiceLocator.auth.login(b.inIdentity.text, b.inPassword.text, b.captcha.captchaCheck.isChecked)
            when (result) {
                is LoginResult.Success -> {
                    val u = result.user
                    startActivity(
                        SuccessActivity.intent(
                            this, "Login berhasil!", "Anda berhasil masuk.\nSilakan masuk untuk mulai antre.",
                            "Masuk sekarang", SuccessActivity.TARGET_MAIN,
                            listOf("Nama" to u.nama, "NIK" to Validators.maskNik(u.nik))
                        )
                    )
                    finish()
                }
                LoginResult.EmptyField -> showError("NIK/email dan kata sandi wajib diisi")
                LoginResult.CaptchaRequired -> showError("Centang verifikasi \"Saya bukan robot\" (CAPTCHA demo)")
                LoginResult.WrongCredential -> showError("Email/password salah", passwordError = true)
            }
        } finally {
            busy = false
        }
    }
}
