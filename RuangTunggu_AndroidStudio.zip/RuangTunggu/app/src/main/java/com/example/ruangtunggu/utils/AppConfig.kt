package com.example.ruangtunggu.utils

/** Semua angka konfigurasi dikumpulkan di sini agar mudah dijelaskan dan diubah. */
object AppConfig {
    /** Notifikasi dikirim ketika sisa antrean <= nilai ini (flowchart hal. 7, wireframe: "sisa antrean <= 2"). */
    const val NOTIF_THRESHOLD = 2

    /** Estimasi lama pelayanan per pasien (menit). Wireframe: sisa 5 -> estimasi 25 menit. */
    const val MINUTES_PER_PATIENT = 5

    /** Nilai awal penghitung antrean per poli per tanggal (demo): pasien pertama mendapat A-023 seperti flowchart. */
    const val INITIAL_SERVING = 18
    const val INITIAL_LAST_ISSUED = 22

    const val MAX_NOTIF_ATTEMPTS = 3
    const val NOTIF_RETRY_DELAY_MS = 30_000L

    const val OTP_LENGTH = 6
    const val OTP_TTL_MS = 5 * 60 * 1000L
    const val OTP_RESEND_SECONDS = 45
    const val OTP_MAX_ATTEMPTS = 5

    const val SCHEDULE_DAYS = 7
    const val DATE_CHIPS = 5
    const val DEFAULT_QUOTA = 15
}
