package com.example.ruangtunggu.ui.queue

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import com.example.ruangtunggu.MainActivity
import com.example.ruangtunggu.R
import com.example.ruangtunggu.ServiceLocator
import com.example.ruangtunggu.data.model.MonitorState
import com.example.ruangtunggu.databinding.FragmentQueueBinding
import com.example.ruangtunggu.ui.common.bind
import com.example.ruangtunggu.ui.common.show
import com.example.ruangtunggu.ui.hospital.SearchHospitalActivity
import com.example.ruangtunggu.utils.AppConfig
import com.example.ruangtunggu.utils.DateUtils
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Pantau Antrean (flowchart hal. 6): ada antrean aktif? -> ambil nomor pasien & nomor dilayani
 * -> hitung sisa & posisi -> tampilkan -> refresh bila diminta.
 */
class QueueFragment : Fragment() {

    private var _b: FragmentQueueBinding? = null
    private val b get() = _b!!

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _b = FragmentQueueBinding.inflate(inflater, container, false)
        return b.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        val main = requireActivity() as MainActivity
        b.header.bind("Pantau Antrean", "Status nomor antrean Anda") { main.selectTab(MainActivity.TAB_HOME) }
        b.btnNewQueue.setOnClickListener { startActivity(SearchHospitalActivity.intent(requireContext())) }
        b.btnRefresh.setOnClickListener { refresh(); Toast.makeText(requireContext(), "Status diperbarui", Toast.LENGTH_SHORT).show() }

        b.cbFailSend.isChecked = ServiceLocator.session.simulateSendFailure
        b.cbFailSend.setOnCheckedChangeListener { _, checked -> ServiceLocator.session.simulateSendFailure = checked }

        b.btnCallNext.setOnClickListener {
            val m = ServiceLocator.queues.monitor(ServiceLocator.session.userId) ?: return@setOnClickListener
            val newServing = ServiceLocator.queues.officerCallNext(m.detail.queue.poliId, m.detail.queue.tanggal)
            // Backend (simulasi): hitung ulang sisa antrean -> kirim notifikasi bila sisa <= batas
            val report = ServiceLocator.monitor.evaluateForUser(ServiceLocator.session.userId)
            val msg = buildString {
                append("Petugas memanggil nomor ").append(newServing)
                if (report.sent > 0) append(" • notifikasi terkirim")
                if (report.scheduledRetry > 0) append(" • kirim gagal, dijadwalkan ulang")
                if (report.failedFinal > 0) append(" • kirim gagal permanen")
            }
            Toast.makeText(requireContext(), msg, Toast.LENGTH_LONG).show()
            refresh()
        }
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun refresh() {
        val userId = ServiceLocator.session.userId
        // Pastikan notifikasi yang jatuh tempo (termasuk coba ulang) ikut dievaluasi
        ServiceLocator.monitor.evaluateForUser(userId)
        val m = ServiceLocator.queues.monitor(userId)
        b.emptyState.show(m == null)
        b.activeState.show(m != null)
        val time = SimpleDateFormat("HH:mm", Locale("id", "ID")).format(Date())
        b.header.headerSubtitle.text = if (m == null) "Status nomor antrean Anda" else "Diperbarui $time"
        if (m != null) bindActive(m)
    }

    private fun bindActive(m: MonitorState) {
        val d = m.detail
        b.tvSisa.text = m.sisa.toString()
        b.ring.setProgressCompat(com.example.ruangtunggu.utils.QueueMath.progress(d.queue.queueNumber, m.serving), true)
        b.tvEstimasi.text = "Estimasi ${m.estimasiMenit} menit"
        b.tvStatus.text = when {
            m.giliranTiba -> "Giliran Anda sedang dilayani. Segera menuju poli."
            m.sisa <= AppConfig.NOTIF_THRESHOLD -> "Giliran Anda sudah dekat"
            else -> "Menunggu giliran"
        }
        b.tvServingCode.text = m.servingCode
        b.tvMyCode.text = d.queue.queueCode
        b.tvDetailLine.text = "${d.hospitalNama} · Poli ${d.poliNama} · ${DateUtils.shortLabel(d.queue.tanggal)} ${d.jamMulai}"
        b.tvNotifInfo.text = "🔔 Notifikasi dikirim saat sisa antrean ≤ ${AppConfig.NOTIF_THRESHOLD}"

        b.upcomingRow.removeAllViews()
        val dp = resources.displayMetrics.density
        m.upcomingCodes.forEachIndexed { i, code ->
            val mine = i == m.upcomingCodes.lastIndex
            val tv = TextView(requireContext()).apply {
                text = code
                textSize = 12f
                setPadding((12 * dp).toInt(), (7 * dp).toInt(), (12 * dp).toInt(), (7 * dp).toInt())
                setBackgroundResource(R.drawable.bg_chip_order)
                isSelected = mine
                setTextColor(ContextCompat.getColor(context, if (mine) R.color.white else R.color.slate_700))
                layoutParams = ViewGroup.MarginLayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                    .also { it.rightMargin = (6 * dp).toInt() }
            }
            b.upcomingRow.addView(tv)
        }
    }

    override fun onDestroyView() {
        _b = null
        super.onDestroyView()
    }
}
