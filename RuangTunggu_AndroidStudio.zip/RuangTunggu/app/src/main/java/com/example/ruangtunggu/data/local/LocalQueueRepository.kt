package com.example.ruangtunggu.data.local

import android.content.ContentValues
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import com.example.ruangtunggu.data.model.*
import com.example.ruangtunggu.data.repository.*
import com.example.ruangtunggu.utils.AppConfig
import com.example.ruangtunggu.utils.QueueMath
import java.time.LocalDate

class LocalQueueRepository(private val database: AppDatabase) : QueueRepository {

    private val db: SQLiteDatabase get() = database.writableDatabase

    private val detailSelect = """
        SELECT q.queue_id, q.user_id, q.hospital_id, q.poli_id, q.doctor_id, q.schedule_id, q.queue_number,
               q.queue_code, q.tanggal, q.status, q.created_at,
               h.nama, h.alamat, p.nama_poli, p.kode, d.nama, s.jam_mulai
        FROM queues q
        JOIN hospitals h ON h.hospital_id=q.hospital_id
        JOIN polis p ON p.poli_id=q.poli_id
        JOIN doctors d ON d.doctor_id=q.doctor_id
        JOIN schedules s ON s.schedule_id=q.schedule_id
    """

    private fun Cursor.toDetail() = QueueDetail(
        queue = Queue(
            queueId = getLong(0), userId = getLong(1), hospitalId = getLong(2), poliId = getLong(3), doctorId = getLong(4),
            scheduleId = getLong(5), queueNumber = getInt(6), queueCode = getString(7), tanggal = getString(8),
            status = getString(9), createdAt = getLong(10)
        ),
        hospitalNama = getString(11), hospitalAlamat = getString(12), poliNama = getString(13), poliKode = getString(14),
        doctorNama = getString(15), jamMulai = getString(16)
    )

    // ------------------------------------------------------------ pendaftaran (flowchart hal. 5)

    override fun register(userId: Long, scheduleId: Long): RegisterQueueResult {
        var outcome: RegisterQueueResult = RegisterQueueResult.NotFound
        var newQueueId = -1L
        db.beginTransaction() // transaksi eksklusif: dua pendaftaran tidak bisa memakai slot terakhir yang sama
        try {
            val info = db.rawQuery(
                """SELECT s.tanggal, d.doctor_id, p.poli_id, p.hospital_id, p.kode
                   FROM schedules s JOIN doctors d ON d.doctor_id=s.doctor_id JOIN polis p ON p.poli_id=d.poli_id
                   WHERE s.schedule_id=?""", arrayOf(scheduleId.toString())
            ).use { c ->
                if (!c.moveToFirst()) null
                else arrayOf(c.getString(0), c.getString(1), c.getString(2), c.getString(3), c.getString(4))
            }
            if (info == null) {
                outcome = RegisterQueueResult.NotFound
            } else {
                val (tanggal, doctorId, poliId, hospitalId, kode) = info
                // Satu pasien tidak boleh memegang dua antrean aktif pada jadwal yang sama
                val dupId = db.rawQuery(
                    "SELECT queue_id FROM queues WHERE user_id=? AND schedule_id=? AND status='Aktif' LIMIT 1",
                    arrayOf(userId.toString(), scheduleId.toString())
                ).use { if (it.moveToFirst()) it.getLong(0) else -1L }

                if (dupId > 0) {
                    outcome = RegisterQueueResult.Duplicate(loadDetail(dupId)!!)
                } else {
                    // Kurangi kuota hanya jika masih > 0 (kondisional + atomik)
                    val updated = db.compileStatement(
                        "UPDATE schedules SET kuota_tersedia = kuota_tersedia - 1 WHERE schedule_id=? AND kuota_tersedia>0"
                    ).use { it.bindLong(1, scheduleId); it.executeUpdateDelete() }

                    if (updated == 0) {
                        outcome = RegisterQueueResult.SlotFull
                    } else {
                        ensureQueueState(poliId.toLong(), tanggal)
                        db.execSQL(
                            "UPDATE queue_state SET last_issued = MAX(last_issued, serving) + 1 WHERE poli_id=? AND tanggal=?",
                            arrayOf(poliId, tanggal)
                        )
                        val number = db.rawQuery(
                            "SELECT last_issued FROM queue_state WHERE poli_id=? AND tanggal=?", arrayOf(poliId, tanggal)
                        ).use { it.moveToFirst(); it.getInt(0) }

                        val cv = ContentValues().apply {
                            put("user_id", userId); put("hospital_id", hospitalId.toLong()); put("poli_id", poliId.toLong())
                            put("doctor_id", doctorId.toLong()); put("schedule_id", scheduleId); put("queue_number", number)
                            put("queue_code", QueueMath.code(kode, number)); put("tanggal", tanggal)
                            put("status", QueueStatus.AKTIF); put("created_at", System.currentTimeMillis())
                        }
                        newQueueId = db.insertOrThrow("queues", null, cv)
                    }
                }
            }
            db.setTransactionSuccessful()
        } finally {
            db.endTransaction()
        }
        if (newQueueId > 0) outcome = RegisterQueueResult.Success(loadDetail(newQueueId)!!)
        return outcome
    }

    private fun ensureQueueState(poliId: Long, tanggal: String) {
        db.execSQL(
            "INSERT OR IGNORE INTO queue_state(poli_id,tanggal,last_issued,serving) VALUES(?,?,?,?)",
            arrayOf<Any>(poliId, tanggal, AppConfig.INITIAL_LAST_ISSUED, AppConfig.INITIAL_SERVING)
        )
    }

    private fun loadDetail(queueId: Long): QueueDetail? =
        db.rawQuery("$detailSelect WHERE q.queue_id=?", arrayOf(queueId.toString()))
            .use { if (it.moveToFirst()) it.toDetail() else null }

    // ------------------------------------------------------------ pembatalan (flowchart hal. 8)

    override fun cancel(userId: Long, queueId: Long): CancelResult {
        var result: CancelResult = CancelResult.NotFound
        db.beginTransaction()
        try {
            val row = db.rawQuery(
                "SELECT status, schedule_id, poli_id, tanggal, queue_number FROM queues WHERE queue_id=? AND user_id=?",
                arrayOf(queueId.toString(), userId.toString())
            ).use { c ->
                if (!c.moveToFirst()) null else arrayOf(c.getString(0), c.getString(1), c.getString(2), c.getString(3), c.getString(4))
            }
            if (row != null) {
                val (status, scheduleId, poliId, tanggal, number) = row
                val serving = servingFor(poliId.toLong(), tanggal)
                if (status != QueueStatus.AKTIF || serving >= number.toInt()) {
                    result = CancelResult.NotActive
                } else {
                    // Perubahan status kondisional: hanya satu pemanggilan yang bisa lolos => kuota kembali tepat sekali
                    val changed = db.compileStatement(
                        "UPDATE queues SET status='Batal' WHERE queue_id=? AND user_id=? AND status='Aktif'"
                    ).use { it.bindLong(1, queueId); it.bindLong(2, userId); it.executeUpdateDelete() }
                    if (changed == 1) {
                        db.execSQL(
                            "UPDATE schedules SET kuota_tersedia = kuota_tersedia + 1 WHERE schedule_id=? AND kuota_tersedia < kuota_total",
                            arrayOf(scheduleId)
                        )
                        result = CancelResult.Success
                    } else {
                        result = CancelResult.NotActive
                    }
                }
            }
            db.setTransactionSuccessful()
        } finally {
            db.endTransaction()
        }
        return result
    }

    // ------------------------------------------------------------ riwayat & detail

    override fun detail(userId: Long, queueId: Long): QueueDetail? =
        db.rawQuery("$detailSelect WHERE q.queue_id=? AND q.user_id=?", arrayOf(queueId.toString(), userId.toString()))
            .use { if (it.moveToFirst()) it.toDetail() else null }

    override fun history(userId: Long, status: String): List<QueueDetail> {
        syncStatuses(userId)
        val out = ArrayList<QueueDetail>()
        db.rawQuery(
            "$detailSelect WHERE q.user_id=? AND q.status=? ORDER BY q.tanggal DESC, q.created_at DESC",
            arrayOf(userId.toString(), status)
        ).use { c -> while (c.moveToNext()) out.add(c.toDetail()) }
        return out
    }

    override fun activeQueues(userId: Long): List<QueueDetail> {
        syncStatuses(userId)
        val out = ArrayList<QueueDetail>()
        db.rawQuery(
            "$detailSelect WHERE q.user_id=? AND q.status='Aktif' ORDER BY q.tanggal ASC, s.jam_mulai ASC, q.queue_number ASC",
            arrayOf(userId.toString())
        ).use { c -> while (c.moveToNext()) out.add(c.toDetail()) }
        return out
    }

    override fun syncStatuses(userId: Long) {
        val today = LocalDate.now().toString()
        // Tanggal sudah lewat -> Selesai
        db.execSQL("UPDATE queues SET status='Selesai' WHERE user_id=? AND status='Aktif' AND tanggal<?", arrayOf<Any>(userId, today))
        // Nomor sudah dilewati petugas -> Selesai
        db.execSQL(
            """UPDATE queues SET status='Selesai' WHERE user_id=? AND status='Aktif' AND queue_number <
               COALESCE((SELECT serving FROM queue_state qs WHERE qs.poli_id=queues.poli_id AND qs.tanggal=queues.tanggal), 0)""",
            arrayOf<Any>(userId)
        )
    }

    // ------------------------------------------------------------ pantau antrean (flowchart hal. 6)

    override fun monitor(userId: Long): MonitorState? {
        val detail = activeQueues(userId).firstOrNull() ?: return null
        val serving = servingFor(detail.queue.poliId, detail.queue.tanggal)
        val n = detail.queue.queueNumber
        val sisa = QueueMath.sisa(n, serving)
        return MonitorState(
            detail = detail,
            serving = serving,
            servingCode = QueueMath.code(detail.poliKode, serving),
            sisa = sisa,
            estimasiMenit = QueueMath.estimasiMenit(sisa),
            upcomingCodes = QueueMath.upcoming(n, serving).map { QueueMath.code(detail.poliKode, it) },
            giliranTiba = serving >= n
        )
    }

    override fun servingFor(poliId: Long, tanggal: String): Int =
        db.rawQuery("SELECT serving FROM queue_state WHERE poli_id=? AND tanggal=?", arrayOf(poliId.toString(), tanggal))
            .use { if (it.moveToFirst()) it.getInt(0) else AppConfig.INITIAL_SERVING }

    override fun officerCallNext(poliId: Long, tanggal: String): Int {
        db.beginTransaction()
        try {
            ensureQueueState(poliId, tanggal)
            // Petugas boleh maju sampai satu nomor setelah nomor terakhir (artinya semua antrean sudah selesai).
            // Pendaftar baru setelah itu mendapat nomor MAX(last_issued, serving)+1, jadi nomor tetap unik.
            db.execSQL(
                "UPDATE queue_state SET serving = serving + 1 WHERE poli_id=? AND tanggal=? AND serving <= last_issued",
                arrayOf<Any>(poliId, tanggal)
            )
            db.setTransactionSuccessful()
        } finally {
            db.endTransaction()
        }
        return servingFor(poliId, tanggal)
    }

    // ------------------------------------------------------------ log notifikasi

    override fun notifLog(queueId: Long): NotifLogRow? =
        db.rawQuery(
            "SELECT queue_id,status,attempts,next_retry_at,message,sisa,created_at,sent_at FROM notif_log WHERE queue_id=?",
            arrayOf(queueId.toString())
        ).use { c ->
            if (!c.moveToFirst()) null
            else NotifLogRow(
                c.getLong(0), c.getString(1), c.getInt(2), c.getLong(3), c.getString(4), c.getInt(5), c.getLong(6),
                if (c.isNull(7)) null else c.getLong(7)
            )
        }

    override fun saveNotifLog(row: NotifLogRow) {
        val cv = ContentValues().apply {
            put("queue_id", row.queueId); put("status", row.status); put("attempts", row.attempts)
            put("next_retry_at", row.nextRetryAt); put("message", row.message); put("sisa", row.sisa)
            put("created_at", row.createdAt); put("sent_at", row.sentAt)
        }
        db.insertWithOnConflict("notif_log", null, cv, SQLiteDatabase.CONFLICT_REPLACE)
    }

    override fun sentNotifications(userId: Long): List<NotificationItem> {
        val out = ArrayList<NotificationItem>()
        db.rawQuery(
            """SELECT q.queue_code, p.nama_poli, n.sisa, n.message, n.sent_at
               FROM notif_log n JOIN queues q ON q.queue_id=n.queue_id JOIN polis p ON p.poli_id=q.poli_id
               WHERE q.user_id=? AND n.status='SENT' ORDER BY n.sent_at DESC""",
            arrayOf(userId.toString())
        ).use { c -> while (c.moveToNext()) out.add(NotificationItem(c.getString(0), c.getString(1), c.getInt(2), c.getString(3), c.getLong(4))) }
        return out
    }
}
