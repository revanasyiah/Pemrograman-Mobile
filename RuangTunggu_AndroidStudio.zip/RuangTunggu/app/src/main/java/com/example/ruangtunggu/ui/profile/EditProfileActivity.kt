package com.example.ruangtunggu.ui.profile

import android.app.Activity
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.ruangtunggu.ServiceLocator
import com.example.ruangtunggu.data.repository.ProfileForm
import com.example.ruangtunggu.data.repository.ProfileResult
import com.example.ruangtunggu.databinding.ActivityEditProfileBinding
import com.example.ruangtunggu.ui.common.InputState
import com.example.ruangtunggu.ui.common.bind
import com.example.ruangtunggu.ui.common.show
import com.example.ruangtunggu.utils.Validators

/** Ubah Profil (flowchart hal. 2): validasi -> "Data tidak valid" atau simpan -> "Profil berhasil diperbarui". */
class EditProfileActivity : AppCompatActivity() {

    private lateinit var b: ActivityEditProfileBinding
    private var gender: String? = null
    private var userId = -1L

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityEditProfileBinding.inflate(layoutInflater)
        setContentView(b.root)
        b.header.bind("Ubah Profil", "Perbarui data diri Anda") { finish() }

        val u = ServiceLocator.auth.currentUser()
        if (u == null) { finish(); return }
        userId = u.userId
        b.inNama.text = u.nama
        b.inNik.text = u.nik
        b.inBirth.text = Validators.isoToInput(u.tanggalLahir)
        b.inPhone.text = u.nomorHp.orEmpty()
        setGender(u.jenisKelamin)

        b.genderL.setOnClickListener { setGender("Laki-laki") }
        b.genderP.setOnClickListener { setGender("Perempuan") }
        b.btnSave.setOnClickListener { save() }
    }

    private fun setGender(g: String?) {
        gender = g
        b.genderL.isSelected = g == "Laki-laki"
        b.genderP.isSelected = g == "Perempuan"
    }

    private fun save() {
        b.btnSave.isEnabled = false // cegah ketukan ganda
        try {
            listOf(b.inNama, b.inNik, b.inBirth, b.inPhone).forEach { it.setState(InputState.NORMAL) }
            b.banner.root.show(false)
            val form = ProfileForm(b.inNama.text, b.inNik.text, b.inBirth.text, gender, b.inPhone.text)
            when (val r = ServiceLocator.auth.updateProfile(userId, form)) {
                is ProfileResult.Success -> {
                    setResult(Activity.RESULT_OK)
                    finish()
                }
                is ProfileResult.Invalid -> {
                    val map = mapOf("nama" to b.inNama, "nik" to b.inNik, "birth" to b.inBirth, "phone" to b.inPhone)
                    r.errors.keys.forEach { map[it]?.setState(InputState.ERROR) }
                    b.banner.bannerText.text = "Data tidak valid"
                    b.banner.root.show(true)
                }
            }
        } finally {
            b.btnSave.isEnabled = true
        }
    }
}
