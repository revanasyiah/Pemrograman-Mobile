package com.example.ruangtunggu.ui.hospital

import android.content.Context
import android.content.Intent
import android.graphics.Typeface
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.ruangtunggu.R
import com.example.ruangtunggu.ServiceLocator
import com.example.ruangtunggu.data.model.HospitalWithPolis
import com.example.ruangtunggu.data.repository.HospitalSearch
import com.example.ruangtunggu.databinding.ActivitySearchHospitalBinding
import com.example.ruangtunggu.databinding.ItemHospitalBinding
import com.example.ruangtunggu.ui.common.bind
import com.example.ruangtunggu.ui.common.hospitalPhoto
import com.example.ruangtunggu.ui.common.show
import java.util.Locale

/**
 * Cari RS & Poli (flowchart hal. 3):
 * kata kunci -> cari -> ditemukan? tampilkan daftar : "Data tidak ditemukan" -> pilih RS (lalu poli di layar berikutnya).
 */
class SearchHospitalActivity : AppCompatActivity() {

    private lateinit var b: ActivitySearchHospitalBinding
    private lateinit var all: List<HospitalWithPolis>
    private var filter = "Semua"
    private var selectedId = -1L
    private val adapter = HospitalAdapter { selectedId = it; render() }
    private val filterViews = ArrayList<TextView>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivitySearchHospitalBinding.inflate(layoutInflater)
        setContentView(b.root)
        b.header.bind("Cari RS & Poli", "Temukan layanan terdekat") { finish() }

        all = ServiceLocator.hospitals.allHospitals()
        b.rvHospitals.layoutManager = LinearLayoutManager(this)
        b.rvHospitals.adapter = adapter
        buildFilters()

        b.etSearch.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, c: Int, d: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, c: Int, d: Int) {}
            override fun afterTextChanged(s: Editable?) { selectedId = -1; render() }
        })
        b.btnClear.setOnClickListener { b.etSearch.setText("") }
        b.btnClearSearch.setOnClickListener { b.etSearch.setText(""); setFilter("Semua") }
        b.btnSelect.setOnClickListener {
            if (selectedId > 0) {
                val hint = HospitalSearch.poliHint(b.etSearch.text.toString(), filter)
                startActivity(SelectPoliActivity.intent(this, selectedId, hint))
            }
        }

        intent.getStringExtra(EXTRA_QUERY)?.let { b.etSearch.setText(it) }
        intent.getStringExtra(EXTRA_FILTER)?.let { filter = it }
        render()
    }

    private fun buildFilters() {
        val dp = resources.displayMetrics.density
        for (name in HospitalSearch.FILTERS) {
            val tv = TextView(this).apply {
                text = name
                textSize = 12f
                setTypeface(typeface, Typeface.BOLD)
                setBackgroundResource(R.drawable.bg_chip_order)
                setPadding((14 * dp).toInt(), (8 * dp).toInt(), (14 * dp).toInt(), (8 * dp).toInt())
                layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT)
                    .also { it.rightMargin = (8 * dp).toInt() }
                setOnClickListener { setFilter(name) }
            }
            filterViews.add(tv)
            b.filterRow.addView(tv)
        }
    }

    private fun setFilter(name: String) { filter = name; selectedId = -1; render() }

    private fun render() {
        filterViews.forEach {
            val on = it.text.toString() == filter
            it.isSelected = on
            it.setTextColor(ContextCompat.getColor(this, if (on) R.color.white else R.color.slate_600))
        }
        val query = b.etSearch.text.toString()
        b.btnClear.show(query.isNotEmpty())

        val result = HospitalSearch.filter(all, query, filter)
        adapter.submit(result, selectedId)
        val found = result.isNotEmpty()
        b.rvHospitals.show(found)
        b.emptyState.show(!found)
        b.tvCount.text = if (found) "${result.size} hasil ditemukan" else ""
        b.btnSelect.show(found)
        b.btnClearSearch.show(!found)
        b.btnSelect.isEnabled = selectedId > 0
        if (!found) {
            b.tvEmptyDesc.text = if (query.isNotBlank())
                "Kami tidak menemukan \"${query.trim()}\".\nCoba kata kunci lain atau periksa ejaan."
            else "Tidak ada rumah sakit untuk filter \"$filter\"."
        }
    }

    companion object {
        const val EXTRA_QUERY = "query"
        const val EXTRA_FILTER = "filter"
        fun intent(ctx: Context, query: String? = null, filter: String? = null): Intent =
            Intent(ctx, SearchHospitalActivity::class.java).putExtra(EXTRA_QUERY, query).putExtra(EXTRA_FILTER, filter)
    }
}

class HospitalAdapter(private val onSelect: (Long) -> Unit) : RecyclerView.Adapter<HospitalAdapter.VH>() {
    private var items: List<HospitalWithPolis> = emptyList()
    private var selected = -1L

    fun submit(list: List<HospitalWithPolis>, selectedId: Long) { items = list; selected = selectedId; notifyDataSetChanged() }

    class VH(val b: ItemHospitalBinding) : RecyclerView.ViewHolder(b.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        VH(ItemHospitalBinding.inflate(LayoutInflater.from(parent.context), parent, false))

    override fun getItemCount() = items.size

    override fun onBindViewHolder(holder: VH, position: Int) {
        val hw = items[position]
        val b = holder.b
        val ctx = b.root.context
        val h = hw.hospital
        b.tvName.text = h.nama
        b.tvMeta.text = "★ %.1f · %.1f km · %s".format(Locale.US, h.rating, h.jarakKm, h.jamBuka)
        val photo = hospitalPhoto(h.foto)
        if (photo != null) {
            b.imgPhoto.imageTintList = null; b.imgPhoto.setPadding(0, 0, 0, 0); b.imgPhoto.setImageResource(photo)
        } else {
            val p = (22 * ctx.resources.displayMetrics.density).toInt()
            b.imgPhoto.setPadding(p, p, p, p); b.imgPhoto.setImageResource(R.drawable.ic_add_box)
            b.imgPhoto.imageTintList = android.content.res.ColorStateList.valueOf(ContextCompat.getColor(ctx, R.color.teal_900))
        }
        b.tagRow.removeAllViews()
        val dp = ctx.resources.displayMetrics.density
        hw.polis.take(3).forEach { p ->
            b.tagRow.addView(TextView(ctx).apply {
                text = p.namaPoli; textSize = 10f; setTypeface(typeface, Typeface.BOLD)
                setTextColor(ContextCompat.getColor(ctx, R.color.teal_900))
                setBackgroundResource(R.drawable.bg_badge_active)
                setPadding((10 * dp).toInt(), (3 * dp).toInt(), (10 * dp).toInt(), (3 * dp).toInt())
                layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT)
                    .also { it.rightMargin = (6 * dp).toInt() }
            })
        }
        val sel = h.hospitalId == selected
        b.cardRoot.setBackgroundResource(if (sel) R.drawable.bg_card_selected else R.drawable.bg_card)
        b.imgCheck.isSelected = sel
        b.imgCheck.visibility = if (sel) android.view.View.VISIBLE else android.view.View.GONE
        b.cardRoot.setOnClickListener { onSelect(h.hospitalId) }
    }
}
