package com.example.ruangtunggu.data.local

import android.database.Cursor
import com.example.ruangtunggu.data.model.*
import com.example.ruangtunggu.data.repository.HospitalRepository
import java.time.LocalDate

class LocalHospitalRepository(private val database: AppDatabase) : HospitalRepository {

    private val db get() = database.readableDatabase

    private fun Cursor.toHospital() = Hospital(
        hospitalId = getLong(0), nama = getString(1), alamat = getString(2), kontak = getString(3),
        rating = getDouble(4), jarakKm = getDouble(5), jamBuka = getString(6), foto = getString(7)
    )

    private val hospitalCols = "hospital_id,nama,alamat,kontak,rating,jarak_km,jam_buka,foto"

    override fun allHospitals(): List<HospitalWithPolis> {
        val list = ArrayList<Hospital>()
        db.rawQuery("SELECT $hospitalCols FROM hospitals ORDER BY hospital_id", null).use { c ->
            while (c.moveToNext()) list.add(c.toHospital())
        }
        return list.map { HospitalWithPolis(it, polisOf(it.hospitalId)) }
    }

    override fun getHospital(hospitalId: Long): Hospital? =
        db.rawQuery("SELECT $hospitalCols FROM hospitals WHERE hospital_id=?", arrayOf(hospitalId.toString()))
            .use { if (it.moveToFirst()) it.toHospital() else null }

    /** Poli + jumlah dokter + jam mulai paling awal sejak hari ini (dihitung dari data jadwal). */
    override fun polisOf(hospitalId: Long): List<Poli> {
        val today = LocalDate.now().toString()
        val out = ArrayList<Poli>()
        db.rawQuery(
            """SELECT p.poli_id, p.hospital_id, p.nama_poli, p.kode,
                      (SELECT COUNT(*) FROM doctors d WHERE d.poli_id=p.poli_id),
                      (SELECT MIN(s.jam_mulai) FROM schedules s JOIN doctors d ON d.doctor_id=s.doctor_id
                         WHERE d.poli_id=p.poli_id AND s.tanggal>=?)
               FROM polis p WHERE p.hospital_id=? ORDER BY p.poli_id""",
            arrayOf(today, hospitalId.toString())
        ).use { c ->
            while (c.moveToNext()) out.add(Poli(c.getLong(0), c.getLong(1), c.getString(2), c.getString(3), c.getInt(4), c.getString(5)))
        }
        return out
    }

    override fun getPoli(poliId: Long): Poli? =
        db.rawQuery("SELECT poli_id,hospital_id,nama_poli,kode FROM polis WHERE poli_id=?", arrayOf(poliId.toString()))
            .use { if (it.moveToFirst()) Poli(it.getLong(0), it.getLong(1), it.getString(2), it.getString(3)) else null }

    override fun doctorSchedules(poliId: Long, tanggal: String): List<DoctorSchedule> {
        val docs = ArrayList<Doctor>()
        db.rawQuery(
            "SELECT doctor_id,poli_id,nama,spesialis,rating,pengalaman FROM doctors WHERE poli_id=? ORDER BY doctor_id",
            arrayOf(poliId.toString())
        ).use { c -> while (c.moveToNext()) docs.add(c.toDoctor()) }

        val result = ArrayList<DoctorSchedule>()
        for (d in docs) {
            val slots = ArrayList<Schedule>()
            db.rawQuery(
                """SELECT schedule_id,doctor_id,tanggal,jam_mulai,jam_selesai,kuota_total,kuota_tersedia
                   FROM schedules WHERE doctor_id=? AND tanggal=? ORDER BY jam_mulai""",
                arrayOf(d.doctorId.toString(), tanggal)
            ).use { c -> while (c.moveToNext()) slots.add(c.toSchedule()) }
            if (slots.isNotEmpty()) result.add(DoctorSchedule(d, slots))
        }
        return result
    }

    override fun scheduleDetail(scheduleId: Long): ScheduleDetail? {
        val schedule = db.rawQuery(
            "SELECT schedule_id,doctor_id,tanggal,jam_mulai,jam_selesai,kuota_total,kuota_tersedia FROM schedules WHERE schedule_id=?",
            arrayOf(scheduleId.toString())
        ).use { if (it.moveToFirst()) it.toSchedule() else null } ?: return null
        val doctor = db.rawQuery(
            "SELECT doctor_id,poli_id,nama,spesialis,rating,pengalaman FROM doctors WHERE doctor_id=?",
            arrayOf(schedule.doctorId.toString())
        ).use { if (it.moveToFirst()) it.toDoctor() else null } ?: return null
        val poli = getPoli(doctor.poliId) ?: return null
        val hospital = getHospital(poli.hospitalId) ?: return null
        return ScheduleDetail(schedule, doctor, poli, hospital)
    }

    private fun Cursor.toDoctor() = Doctor(getLong(0), getLong(1), getString(2), getString(3), getDouble(4), getInt(5))

    private fun Cursor.toSchedule() = Schedule(getLong(0), getLong(1), getString(2), getString(3), getString(4), getInt(5), getInt(6))
}
