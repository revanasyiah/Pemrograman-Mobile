package com.example.ruangtunggu.data.repository

import com.example.ruangtunggu.data.model.QueueDetail
import com.example.ruangtunggu.data.remote.NotificationSender
import com.example.ruangtunggu.utils.AppConfig
import com.example.ruangtunggu.utils.NotifDecision
import com.example.ruangtunggu.utils.NotifStatus
import com.example.ruangtunggu.utils.NotificationPolicy
import com.example.ruangtunggu.utils.QueueMath

/**
 * Proses flowchart hal. 7, versi lokal:
 *   nomor dilayani berubah -> hitung sisa tiap antrean -> sisa <= batas? -> kirim lewat [NotificationSender]
 *   -> gagal? jadwalkan kirim ulang : tandai terkirim.
 *
 * - Keputusan ada di [NotificationPolicy] (murni); pengiriman ada di [NotificationSender] (bisa diganti FCM).
 * - Satu baris notif_log per antrean => kondisi yang sama tidak mengirim notifikasi dua kali.
 * - Coba ulang dijalankan setiap [evaluateForUser] dipanggil (saat aplikasi terbuka/refresh). Tidak ada
 *   worker latar belakang pada versi demo ini.
 */
class QueueMonitorService(
    private val queues: QueueRepository,
    private val sender: NotificationSender,
    private val clock: () -> Long = { System.currentTimeMillis() }
) {
    data class Report(val sent: Int, val scheduledRetry: Int, val failedFinal: Int)

    fun evaluateForUser(userId: Long): Report {
        var sent = 0; var retry = 0; var failed = 0
        for (detail in queues.activeQueues(userId)) {
            when (evaluateOne(detail)) {
                NotifStatus.SENT -> sent++
                NotifStatus.RETRY -> retry++
                NotifStatus.FAILED -> failed++
            }
        }
        return Report(sent, retry, failed)
    }

    /** @return status baru jika ada percobaan kirim pada pemanggilan ini, null jika dilewati. */
    private fun evaluateOne(detail: QueueDetail): String? {
        val q = detail.queue
        val serving = queues.servingFor(q.poliId, q.tanggal)
        val sisa = QueueMath.sisa(q.queueNumber, serving)
        val log = queues.notifLog(q.queueId)
        val now = clock()

        val decision = NotificationPolicy.decide(sisa, AppConfig.NOTIF_THRESHOLD, log?.status, log?.nextRetryAt ?: 0L, now)
        if (decision == NotifDecision.SKIP) return null

        val message = if (sisa <= 0) "Giliran Anda sekarang. Segera menuju Poli ${detail.poliNama}."
        else "Sisa $sisa antrean. Segera menuju Poli ${detail.poliNama}."
        val attempts = (log?.attempts ?: 0) + 1
        val createdAt = log?.createdAt ?: now

        val ok = sender.send(detail, sisa, message)
        val row = if (ok) {
            NotifLogRow(q.queueId, NotifStatus.SENT, attempts, 0L, message, sisa, createdAt, now)
        } else if (attempts >= AppConfig.MAX_NOTIF_ATTEMPTS) {
            NotifLogRow(q.queueId, NotifStatus.FAILED, attempts, 0L, message, sisa, createdAt, null)
        } else {
            NotifLogRow(q.queueId, NotifStatus.RETRY, attempts, now + AppConfig.NOTIF_RETRY_DELAY_MS, message, sisa, createdAt, null)
        }
        queues.saveNotifLog(row)
        return row.status
    }
}
