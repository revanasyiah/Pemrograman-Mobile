package com.example.ruangtunggu.utils

import java.security.MessageDigest
import java.security.SecureRandom
import java.util.Base64
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec

/** Hash kata sandi PBKDF2-HMAC-SHA256 + salt acak. Kata sandi tidak pernah disimpan/dicatat. */
object PasswordHasher {
    private const val ITER = 120_000
    private const val KEY_BITS = 256

    fun newSalt(): String {
        val b = ByteArray(16); SecureRandom().nextBytes(b)
        return Base64.getEncoder().encodeToString(b)
    }

    fun hash(password: String, salt: String): String {
        val spec = PBEKeySpec(password.toCharArray(), Base64.getDecoder().decode(salt), ITER, KEY_BITS)
        val key = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded
        spec.clearPassword()
        return Base64.getEncoder().encodeToString(key)
    }

    fun verify(password: String, salt: String, expected: String): Boolean =
        MessageDigest.isEqual(hash(password, salt).toByteArray(), expected.toByteArray())
}
