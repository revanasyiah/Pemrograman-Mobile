package com.example.ruangtunggu.ui.schedule

import android.content.Context
import android.content.Intent
import android.graphics.Paint
import android.graphics.Typeface
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.example.ruangtunggu.R
import com.example.ruangtunggu.ServiceLocator
import com.example.ruangtunggu.data.model.DoctorSchedule
import com.example.ruangtunggu.databinding.ActivitySelectScheduleBinding
import com.example.ruangtunggu.databinding.ItemDoctorScheduleBinding
import com.example.ruangtunggu.ui.common.bind
import com.example.ruangtunggu.ui.common.show
import com.example.ruangtunggu.ui.registration.SummaryActivity
import com.example.ruangtunggu.utils.AppConfig
import com.example.ruangtunggu.utils.DateUtils
import java.time.LocalDate
import java.util.Locale

/**
 * Pilih Dokter & Jadwal (flowchart hal. 4):
 * pilih poli -> ambil dokter & jadwal -> tersedia? daftar : "Jadwal belum tersedia" -> pilih dokter & jam.
 */
class SelectScheduleActivity : AppCompatActivity() {

    private lateinit var b: ActivitySelectScheduleBinding
    private var poliId = -1L
    private var date: LocalDate = LocalDate.now()
    private var selectedScheduleId = -1L
    private val dateViews = ArrayList<Pair<LocalDate, TextView>>()
    private val slotViews = ArrayList<Pair<Long, TextView>>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivitySelectScheduleBinding.inflate(layoutInflater)
        setContentView(b.root)

        poliId = intent.getLongExtra(EXTRA_POLI_ID, -1)
        val poli = ServiceLocator.hospitals.getPoli(poliId)
        val hospital = poli?.let { ServiceLocator.hospitals.getHospital(it.hospitalId) }
        if (poli == null || hospital == null) { finish(); return }
        b.header.bind("Pilih Dokter & Jadwal", "${poli.label} · ${hospital.nama}") { finish() }

        buildDates()
        b.btnNext.setOnClickListener {
            if (selectedScheduleId > 0) startActivity(SummaryActivity.intent(this, selectedScheduleId))
        }
        loadDay()
    }

    private fun buildDates() {
        val today = LocalDate.now()
        val dp = resources.displayMetrics.density
        for (i in 0 until AppConfig.DATE_CHIPS) {
            val d = today.plusDays(i.toLong())
            val tv = TextView(this).apply {
                text = "${DateUtils.dayShort(d)}\n${d.dayOfMonth}"
                gravity = Gravity.CENTER
                textSize = 13f
                setTypeface(typeface, Typeface.BOLD)
                setBackgroundResource(R.drawable.bg_date)
                setTextColor(ContextCompat.getColorStateList(context, R.color.date_text))
                setPadding(0, (8 * dp).toInt(), 0, (8 * dp).toInt())
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                    .also { it.setMargins((3 * dp).toInt(), 0, (3 * dp).toInt(), 0) }
                setOnClickListener { date = d; selectedScheduleId = -1; loadDay() }
            }
            dateViews.add(d to tv)
            b.dateRow.addView(tv)
        }
    }

    private fun loadDay() {
        dateViews.forEach { (d, tv) -> tv.isSelected = d == date }
        b.tvDateLabel.text = DateUtils.mediumLabel(date.toString())
        val list: List<DoctorSchedule> = ServiceLocator.hospitals.doctorSchedules(poliId, date.toString())

        b.doctorList.removeAllViews()
        slotViews.clear()
        val none = list.isEmpty()
        b.emptyState.show(none)
        b.doctorList.show(!none)
        for (ds in list) {
            val item = ItemDoctorScheduleBinding.inflate(layoutInflater, b.doctorList, false)
            item.tvDoctor.text = ds.doctor.nama
            item.tvSpecialty.text = ds.doctor.spesialis
            item.tvExperience.text = "★ %.1f · %d tahun pengalaman".format(Locale.US, ds.doctor.rating, ds.doctor.pengalamanTahun)
            val dp = resources.displayMetrics.density
            for (s in ds.slots) {
                val tv = TextView(this).apply {
                    text = s.jamMulai
                    textSize = 12f
                    gravity = Gravity.CENTER
                    setTypeface(typeface, Typeface.BOLD)
                    setBackgroundResource(R.drawable.bg_slot)
                    setTextColor(ContextCompat.getColorStateList(context, R.color.slot_text))
                    setPadding((16 * dp).toInt(), (9 * dp).toInt(), (16 * dp).toInt(), (9 * dp).toInt())
                    layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT)
                        .also { it.rightMargin = (8 * dp).toInt() }
                    if (s.penuh) {
                        isEnabled = false
                        paintFlags = paintFlags or Paint.STRIKE_THRU_TEXT_FLAG // slot penuh dicoret seperti wireframe
                        contentDescription = "${s.jamMulai} penuh"
                    } else {
                        setOnClickListener { selectedScheduleId = s.scheduleId; refreshSlots() }
                    }
                }
                slotViews.add(s.scheduleId to tv)
                item.slotRow.addView(tv)
            }
            b.doctorList.addView(item.root)
        }
        refreshSlots()
    }

    private fun refreshSlots() {
        slotViews.forEach { (id, tv) -> tv.isSelected = id == selectedScheduleId }
        b.btnNext.isEnabled = selectedScheduleId > 0
        b.btnNext.visibility = View.VISIBLE
    }

    companion object {
        const val EXTRA_POLI_ID = "poli_id"
        fun intent(ctx: Context, poliId: Long): Intent = Intent(ctx, SelectScheduleActivity::class.java).putExtra(EXTRA_POLI_ID, poliId)
    }
}
