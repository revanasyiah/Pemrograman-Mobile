package com.example.ruangtunggu

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import com.example.ruangtunggu.databinding.ActivityMainBinding
import com.example.ruangtunggu.ui.auth.LoginActivity
import com.example.ruangtunggu.ui.history.HistoryFragment
import com.example.ruangtunggu.ui.home.HomeFragment
import com.example.ruangtunggu.ui.profile.ProfileFragment
import com.example.ruangtunggu.ui.queue.QueueFragment

/** Host untuk 4 tab bottom navigation: Beranda, Antrean (Pantau), Riwayat, Profil. */
class MainActivity : AppCompatActivity() {

    private lateinit var b: ActivityMainBinding
    private var currentTab = -1

    private val notifPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { /* hasil tidak wajib */ }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Pengguna tanpa sesi tidak boleh masuk halaman utama
        if (!ServiceLocator.session.isLoggedIn() || ServiceLocator.auth.currentUser() == null) {
            ServiceLocator.session.clear()
            startActivity(Intent(this, LoginActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK))
            finish()
            return
        }
        b = ActivityMainBinding.inflate(layoutInflater)
        setContentView(b.root)

        b.bottomNav.setOnItemSelectedListener { item ->
            val tab = when (item.itemId) {
                R.id.nav_home -> TAB_HOME
                R.id.nav_queue -> TAB_QUEUE
                R.id.nav_history -> TAB_HISTORY
                else -> TAB_PROFILE
            }
            showTab(tab)
            true
        }
        val start = savedInstanceState?.getInt(STATE_TAB) ?: intent.getIntExtra(EXTRA_TAB, TAB_HOME)
        selectTab(start)

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (currentTab != TAB_HOME) selectTab(TAB_HOME) else finish()
            }
        })

        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) notifPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
    }

    override fun onResume() {
        super.onResume()
        if (ServiceLocator.session.isLoggedIn()) {
            // Evaluasi notifikasi (termasuk coba-ulang yang jatuh tempo) setiap aplikasi dibuka
            ServiceLocator.monitor.evaluateForUser(ServiceLocator.session.userId)
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putInt(STATE_TAB, currentTab)
    }

    /** Dipanggil fragment/Activity lain untuk berpindah tab. */
    fun selectTab(tab: Int) {
        val id = when (tab) {
            TAB_QUEUE -> R.id.nav_queue
            TAB_HISTORY -> R.id.nav_history
            TAB_PROFILE -> R.id.nav_profile
            else -> R.id.nav_home
        }
        if (b.bottomNav.selectedItemId == id) showTab(tab) else b.bottomNav.selectedItemId = id
    }

    private fun showTab(tab: Int) {
        if (tab == currentTab) return
        currentTab = tab
        val f: Fragment = when (tab) {
            TAB_QUEUE -> QueueFragment()
            TAB_HISTORY -> HistoryFragment()
            TAB_PROFILE -> ProfileFragment()
            else -> HomeFragment()
        }
        supportFragmentManager.beginTransaction().replace(R.id.container, f).commit()
    }

    companion object {
        const val EXTRA_TAB = "tab"
        const val TAB_HOME = 0
        const val TAB_QUEUE = 1
        const val TAB_HISTORY = 2
        const val TAB_PROFILE = 3
        private const val STATE_TAB = "state_tab"
    }
}
