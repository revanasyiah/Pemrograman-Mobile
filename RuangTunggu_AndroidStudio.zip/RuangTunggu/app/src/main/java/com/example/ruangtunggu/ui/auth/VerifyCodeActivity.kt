package com.example.ruangtunggu.ui.auth

import android.os.Bundle
import android.os.CountDownTimer
import android.text.Editable
import android.text.InputFilter
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.KeyEvent
import android.widget.EditText
import android.widget.LinearLayout
import androidx.appcompat.app.AppCompatActivity
import com.example.ruangtunggu.R
import com.example.ruangtunggu.ServiceLocator
import com.example.ruangtunggu.data.repository.*
import com.example.ruangtunggu.databinding.ActivityVerifyCodeBinding
import com.example.ruangtunggu.ui.common.InputState
import com.example.ruangtunggu.ui.common.SuccessActivity
import com.example.ruangtunggu.ui.common.bind
import com.example.ruangtunggu.ui.common.show
import com.example.ruangtunggu.utils.AppConfig

/**
 * Lupa kata sandi, langkah 2 (verifikasi kode) dan 3 (kata sandi baru).
 * Kode valid -> boleh ganti kata sandi; tidak valid -> galat; berhasil -> layar "Kata sandi berhasil diubah".
 * Catatan: wireframe tidak memuat layar kata sandi baru; langkah itu ditambahkan di Activity ini (lihat README, asumsi).
 */
class VerifyCodeActivity : AppCompatActivity() {

    private lateinit var b: ActivityVerifyCodeBinding
    private val boxes = ArrayList<EditText>()
    private var timer: CountDownTimer? = null
    private lateinit var identity: String

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityVerifyCodeBinding.inflate(layoutInflater)
        setContentView(b.root)
        identity = intent.getStringExtra(EXTRA_IDENTITY).orEmpty()
        b.header.bind("Verifikasi Kode", "Langkah 1 dari 2") { finish() }

        showCodeInfo(intent.getStringExtra(EXTRA_DEMO_CODE).orEmpty(), intent.getStringExtra(EXTRA_MASKED).orEmpty())
        buildBoxes()
        startTimer()

        b.btnVerify.setOnClickListener { verify() }
        b.btnResend.setOnClickListener { resend() }
        b.btnSavePass.setOnClickListener { savePassword() }
    }

    private fun showCodeInfo(code: String, masked: String) {
        b.codeSubtitle.text = "Kode ${AppConfig.OTP_LENGTH} digit untuk akun $masked"
        b.demoCode.text = "MODE DEMO: kode Anda $code\n(tidak dikirim lewat email/SMS)"
    }

    private fun buildBoxes() {
        val d = resources.displayMetrics.density
        repeat(AppConfig.OTP_LENGTH) { i ->
            val et = EditText(this).apply {
                layoutParams = LinearLayout.LayoutParams((44 * d).toInt(), (54 * d).toInt()).also { it.setMargins((4 * d).toInt(), 0, (4 * d).toInt(), 0) }
                gravity = Gravity.CENTER
                inputType = InputType.TYPE_CLASS_NUMBER
                filters = arrayOf(InputFilter.LengthFilter(1))
                textSize = 20f
                setTextColor(getColor(R.color.ink))
                setBackgroundResource(R.drawable.bg_otp_box)
                isSaveEnabled = false
            }
            et.addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
                override fun onTextChanged(s: CharSequence?, st: Int, b4: Int, c: Int) {}
                override fun afterTextChanged(s: Editable?) {
                    if (!s.isNullOrEmpty() && i < boxes.size - 1) boxes[i + 1].requestFocus()
                }
            })
            et.setOnKeyListener { _, keyCode, event ->
                if (keyCode == KeyEvent.KEYCODE_DEL && event.action == KeyEvent.ACTION_DOWN && et.text.isEmpty() && i > 0) {
                    boxes[i - 1].setText(""); boxes[i - 1].requestFocus(); true
                } else false
            }
            boxes.add(et)
            b.otpRow.addView(et)
        }
        boxes.first().requestFocus()
    }

    private fun enteredCode() = boxes.joinToString("") { it.text.toString() }

    private fun error(msg: String) {
        b.banner.bannerText.text = msg
        b.banner.root.show(true)
    }

    private fun verify() {
        b.banner.root.show(false)
        val code = enteredCode()
        if (code.length < AppConfig.OTP_LENGTH) { error("Lengkapi ${AppConfig.OTP_LENGTH} digit kode"); return }
        when (val r = ServiceLocator.auth.verifyResetCode(code)) {
            VerifyResult.Valid -> {
                b.header.headerSubtitle.text = "Langkah 2 dari 2"
                b.stepCode.show(false)
                b.stepPassword.show(true)
                timer?.cancel()
            }
            is VerifyResult.Invalid -> { error("Kode salah. Sisa percobaan: ${r.attemptsLeft}"); clearBoxes() }
            VerifyResult.Expired, VerifyResult.NoRequest -> error("Kode kedaluwarsa. Silakan kirim ulang kode.")
            VerifyResult.TooManyAttempts -> error("Terlalu banyak percobaan. Silakan kirim ulang kode.")
        }
    }

    private fun clearBoxes() { boxes.forEach { it.setText("") }; boxes.first().requestFocus() }

    private fun resend() {
        when (val r = ServiceLocator.auth.requestPasswordReset(identity)) {
            is ResetRequestResult.Sent -> {
                showCodeInfo(r.code, r.maskedContact)
                clearBoxes(); b.banner.root.show(false); startTimer()
            }
            else -> error("Tidak dapat mengirim ulang kode")
        }
    }

    private fun startTimer() {
        timer?.cancel()
        b.btnResend.isEnabled = false
        timer = object : CountDownTimer(AppConfig.OTP_RESEND_SECONDS * 1000L, 1000L) {
            override fun onTick(ms: Long) {
                val s = (ms / 1000).toInt()
                b.timerText.text = "Kirim ulang kode dalam %02d:%02d".format(s / 60, s % 60)
            }
            override fun onFinish() {
                b.timerText.text = "Belum menerima kode?"
                b.btnResend.isEnabled = true
            }
        }.start()
    }

    private fun savePassword() {
        b.banner2.root.show(false)
        b.inNewPass.setState(InputState.NORMAL); b.inConfirmPass.setState(InputState.NORMAL)
        val msg = when (ServiceLocator.auth.resetPassword(b.inNewPass.text, b.inConfirmPass.text)) {
            ResetResult.Success -> {
                startActivity(
                    SuccessActivity.intent(
                        this, "Kata sandi berhasil diubah", "Kata sandi baru Anda sudah aktif.\nSilakan masuk dengan kata sandi baru.",
                        "Masuk sekarang", SuccessActivity.TARGET_LOGIN
                    )
                )
                finish()
                return
            }
            ResetResult.WeakPassword -> { b.inNewPass.setState(InputState.ERROR); "Kata sandi minimal 8 karakter, huruf dan angka" }
            ResetResult.Mismatch -> { b.inConfirmPass.setState(InputState.ERROR); "Konfirmasi kata sandi tidak sama" }
            ResetResult.NotVerified -> "Kode belum diverifikasi atau sudah kedaluwarsa"
        }
        b.banner2.bannerText.text = msg
        b.banner2.root.show(true)
    }

    override fun onDestroy() {
        timer?.cancel()
        super.onDestroy()
    }

    companion object {
        const val EXTRA_IDENTITY = "identity"
        const val EXTRA_DEMO_CODE = "demo_code"
        const val EXTRA_MASKED = "masked"
    }
}
