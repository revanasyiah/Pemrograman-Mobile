package com.example.ruangtunggu

import android.app.Application
import android.content.Context
import com.example.ruangtunggu.data.local.AppDatabase
import com.example.ruangtunggu.data.local.LocalAuthRepository
import com.example.ruangtunggu.data.local.LocalHospitalRepository
import com.example.ruangtunggu.data.local.LocalQueueRepository
import com.example.ruangtunggu.data.local.SessionManager
import com.example.ruangtunggu.data.remote.LocalNotificationSender
import com.example.ruangtunggu.data.remote.NotificationSender
import com.example.ruangtunggu.data.repository.AuthRepository
import com.example.ruangtunggu.data.repository.HospitalRepository
import com.example.ruangtunggu.data.repository.QueueMonitorService
import com.example.ruangtunggu.data.repository.QueueRepository

class RuangTungguApp : Application() {
    override fun onCreate() {
        super.onCreate()
        ServiceLocator.init(this)
    }
}

/**
 * Satu tempat untuk merakit dependensi. Untuk pindah ke Firebase, ganti implementasi di sini saja.
 * Seluruh akses data UI melewati interface di paket data.repository.
 */
object ServiceLocator {
    private lateinit var appContext: Context

    fun init(ctx: Context) {
        appContext = ctx.applicationContext
        LocalNotificationSender.ensureChannel(appContext)
        database.ensureSchedules() // buat jadwal 7 hari ke depan bila belum ada
    }

    val database: AppDatabase by lazy { AppDatabase.get(appContext) }
    val session: SessionManager by lazy { SessionManager(appContext) }
    val auth: AuthRepository by lazy { LocalAuthRepository(database, session) }
    val hospitals: HospitalRepository by lazy { LocalHospitalRepository(database) }
    val queues: QueueRepository by lazy { LocalQueueRepository(database) }
    val notifier: NotificationSender by lazy { LocalNotificationSender(appContext, session) }
    val monitor: QueueMonitorService by lazy { QueueMonitorService(queues, notifier) }
}
