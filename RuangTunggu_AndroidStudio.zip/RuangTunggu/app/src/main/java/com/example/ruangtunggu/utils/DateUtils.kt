package com.example.ruangtunggu.utils

import java.time.LocalDate
import java.time.format.TextStyle
import java.util.Locale

object DateUtils {
    private val ID = Locale("id", "ID")
    private val SHORT_MONTH = arrayOf("Jan", "Feb", "Mar", "Apr", "Mei", "Jun", "Jul", "Agu", "Sep", "Okt", "Nov", "Des")
    private val LONG_MONTH = arrayOf("Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember")

    fun today(): LocalDate = LocalDate.now()
    fun iso(d: LocalDate) = d.toString()

    fun dayShort(d: LocalDate): String = d.dayOfWeek.getDisplayName(TextStyle.SHORT, ID).replaceFirstChar { it.uppercase() }
    fun dayLong(d: LocalDate): String = d.dayOfWeek.getDisplayName(TextStyle.FULL, ID).replaceFirstChar { it.uppercase() }

    /** "Kam, 22 Okt" */
    fun shortLabel(iso: String): String { val d = LocalDate.parse(iso); return "${dayShort(d)}, ${d.dayOfMonth} ${SHORT_MONTH[d.monthValue - 1]}" }

    /** "Kamis, 22 Okt" */
    fun mediumLabel(iso: String): String { val d = LocalDate.parse(iso); return "${dayLong(d)}, ${d.dayOfMonth} ${SHORT_MONTH[d.monthValue - 1]}" }

    /** "Kamis, 22 Okt 2026" */
    fun fullLabel(iso: String): String { val d = LocalDate.parse(iso); return "${dayLong(d)}, ${d.dayOfMonth} ${SHORT_MONTH[d.monthValue - 1]} ${d.year}" }

    /** "01 Januari 1995" */
    fun birthLabel(iso: String): String = try {
        val d = LocalDate.parse(iso); "%02d ${LONG_MONTH[d.monthValue - 1]} %d".format(d.dayOfMonth, d.year)
    } catch (e: Exception) { iso }

    fun greeting(hour: Int): String = when (hour) {
        in 4..10 -> "Selamat pagi"
        in 11..14 -> "Selamat siang"
        in 15..17 -> "Selamat sore"
        else -> "Selamat malam"
    }

    fun initials(name: String): String =
        name.trim().split(" ").filter { it.isNotBlank() }.take(2).joinToString("") { it.first().uppercase() }.ifBlank { "?" }
}
