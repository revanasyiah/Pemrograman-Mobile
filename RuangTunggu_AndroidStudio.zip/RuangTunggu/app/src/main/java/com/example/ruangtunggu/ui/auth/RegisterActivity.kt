package com.example.ruangtunggu.ui.auth

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.ruangtunggu.ServiceLocator
import com.example.ruangtunggu.data.repository.RegisterForm
import com.example.ruangtunggu.data.repository.RegisterResult
import com.example.ruangtunggu.databinding.ActivityRegisterBinding
import com.example.ruangtunggu.ui.common.IconInput
import com.example.ruangtunggu.ui.common.InputState
import com.example.ruangtunggu.ui.common.SuccessActivity
import com.example.ruangtunggu.ui.common.bind
import com.example.ruangtunggu.ui.common.show
import com.example.ruangtunggu.utils.Validators

/** Registrasi (flowchart hal. 1): validasi data + keunikan email -> simpan akun -> "Registrasi berhasil". */
class RegisterActivity : AppCompatActivity() {

    private lateinit var b: ActivityRegisterBinding
    private var busy = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityRegisterBinding.inflate(layoutInflater)
        setContentView(b.root)
        b.header.bind("Buat Akun Baru", "Lengkapi data diri Anda") { finish() }

        b.btnRegister.setOnClickListener { submit() }
        b.btnToLogin.setOnClickListener {
            startActivity(Intent(this, LoginActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP))
            finish()
        }
    }

    private fun fieldMap(): Map<String, IconInput> = mapOf(
        "nama" to b.inNama, "contact" to b.inContact, "nik" to b.inNik, "birth" to b.inBirth, "password" to b.inPassword
    )

    private fun submit() {
        if (busy) return
        busy = true
        try {
            fieldMap().values.forEach { it.setState(InputState.NORMAL) }
            b.banner.root.show(false)

            val form = RegisterForm(
                nama = b.inNama.text, contact = b.inContact.text, nik = b.inNik.text, birth = b.inBirth.text,
                password = b.inPassword.text, captchaChecked = b.captcha.captchaCheck.isChecked
            )
            when (val r = ServiceLocator.auth.register(form)) {
                is RegisterResult.Success -> {
                    startActivity(
                        SuccessActivity.intent(
                            this, "Registrasi berhasil!", "Akun Anda sudah dibuat.\nSilakan masuk untuk mulai antre.",
                            "Masuk sekarang", SuccessActivity.TARGET_LOGIN,
                            listOf("Nama" to r.user.nama, "NIK" to Validators.maskNik(r.user.nik))
                        )
                    )
                    finish()
                }
                is RegisterResult.Invalid -> {
                    val map = fieldMap()
                    r.errors.keys.forEach { map[it]?.setState(InputState.ERROR) }
                    val detail = r.errors.values.joinToString("\n") { "• $it" }
                    showBanner("Data tidak valid / email sudah terdaftar\n$detail")
                }
                is RegisterResult.Duplicate -> {
                    when (r.field) {
                        "email", "nomor_hp" -> b.inContact.setState(InputState.ERROR)
                        "nik" -> b.inNik.setState(InputState.ERROR)
                    }
                    showBanner("Data tidak valid / email sudah terdaftar")
                }
            }
        } finally {
            busy = false
        }
    }

    private fun showBanner(msg: String) {
        b.banner.bannerText.text = msg
        b.banner.root.show(true)
    }
}
