package com.example.ruangtunggu.data.model

/*
 * Pemetaan field model -> kolom SQLite (lihat AppDatabase) -> padanan Firestore bila nanti dipindah:
 *   User     users/{userId}
 *   Hospital hospitals/{hospitalId}
 *   Poli     hospitals/{hospitalId}/polis/{poliId}
 *   Doctor   doctors/{doctorId}
 *   Schedule schedules/{scheduleId}  (kuotaTersedia diubah lewat transaksi)
 *   Queue    queues/{queueId}        (hanya bisa dibaca pemilik: userId == request.auth.uid)
 * Kata sandi TIDAK ada di model User; hash disimpan terpisah di tabel users (pass_hash, pass_salt).
 */

data class User(
    val userId: Long,
    val nama: String,
    val email: String?,
    val nomorHp: String?,
    val nik: String,
    val tempatLahir: String,
    val tanggalLahir: String, // ISO yyyy-MM-dd
    val jenisKelamin: String? // "Laki-laki" / "Perempuan" / null (belum diisi)
)

data class Hospital(
    val hospitalId: Long,
    val nama: String,
    val alamat: String,
    val kontak: String,
    val rating: Double,
    val jarakKm: Double,
    val jamBuka: String,
    val foto: String? // nama aset drawable, null = ikon default
)

data class Poli(
    val poliId: Long,
    val hospitalId: Long,
    val namaPoli: String, // contoh: "Anak" (ditampilkan sebagai "Poli Anak")
    val kode: String, // awalan nomor antrean, contoh: "A"
    val jumlahDokter: Int = 0,
    val mulai: String? = null // jam mulai paling awal sejak hari ini, null jika belum ada jadwal
) {
    val label: String get() = "Poli $namaPoli"
}

data class Doctor(
    val doctorId: Long,
    val poliId: Long,
    val nama: String,
    val spesialis: String,
    val rating: Double,
    val pengalamanTahun: Int
)

data class Schedule(
    val scheduleId: Long,
    val doctorId: Long,
    val tanggal: String, // ISO
    val jamMulai: String,
    val jamSelesai: String,
    val kuotaTotal: Int,
    val kuotaTersedia: Int
) {
    val penuh: Boolean get() = kuotaTersedia <= 0
}

object QueueStatus {
    const val AKTIF = "Aktif"
    const val SELESAI = "Selesai"
    const val BATAL = "Batal"
}

data class Queue(
    val queueId: Long,
    val userId: Long,
    val hospitalId: Long,
    val poliId: Long,
    val doctorId: Long,
    val scheduleId: Long,
    val queueNumber: Int,
    val queueCode: String, // contoh "A-023"
    val tanggal: String,
    val status: String,
    val createdAt: Long
)

/** Antrean + data tampilan hasil join (satu sumber data untuk riwayat, tiket, pantau). */
data class QueueDetail(
    val queue: Queue,
    val hospitalNama: String,
    val hospitalAlamat: String,
    val poliNama: String,
    val poliKode: String,
    val doctorNama: String,
    val jamMulai: String
)

data class HospitalWithPolis(val hospital: Hospital, val polis: List<Poli>)

data class DoctorSchedule(val doctor: Doctor, val slots: List<Schedule>)

data class ScheduleDetail(val schedule: Schedule, val doctor: Doctor, val poli: Poli, val hospital: Hospital)

data class MonitorState(
    val detail: QueueDetail,
    val serving: Int,
    val servingCode: String,
    val sisa: Int,
    val estimasiMenit: Int,
    val upcomingCodes: List<String>,
    val giliranTiba: Boolean // nomor pasien sedang dilayani
)

data class NotificationItem(val queueCode: String, val poliNama: String, val sisa: Int, val message: String, val sentAt: Long)
