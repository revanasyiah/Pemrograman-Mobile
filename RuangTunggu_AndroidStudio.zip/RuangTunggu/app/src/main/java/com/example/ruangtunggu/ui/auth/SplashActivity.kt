package com.example.ruangtunggu.ui.auth

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.widget.ImageView
import android.widget.LinearLayout
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import com.example.ruangtunggu.MainActivity
import com.example.ruangtunggu.R
import com.example.ruangtunggu.ServiceLocator
import com.example.ruangtunggu.databinding.ActivitySplashBinding
import com.example.ruangtunggu.ui.common.show

/**
 * Splash + onboarding (wireframe 01-04).
 * Alur: sesi login ada -> Beranda; belum -> halaman sambutan. "Sudah punya akun?" -> Login, selain itu -> Registrasi.
 */
class SplashActivity : AppCompatActivity() {

    private lateinit var b: ActivitySplashBinding
    private val handler = Handler(Looper.getMainLooper())
    private var page = 0

    private val pages by lazy { listOf(b.page0, b.page1, b.page2, b.page3) }

    private val titles = listOf("", "Cari dokter dengan mudah", "Antre dari mana saja", "Dapat notifikasi giliran")
    private val descs = listOf(
        "",
        "Temukan rumah sakit, poli, dan jadwal dokter dalam satu aplikasi.",
        "Daftar dan dapatkan nomor antrean tanpa harus datang lebih awal.",
        "Kami kabari saat giliran Anda dekat agar tidak menunggu lama."
    )

    private val goMain = Runnable {
        startActivity(Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK))
        finish()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivitySplashBinding.inflate(layoutInflater)
        setContentView(b.root)

        // Inisialisasi selesai -> arahkan sesuai status sesi
        val hasSession = ServiceLocator.session.isLoggedIn()
        val validUser = hasSession && ServiceLocator.auth.currentUser() != null
        if (hasSession && !validUser) ServiceLocator.session.clear()

        buildDots()
        showPage(0)
        if (validUser) {
            // Pengguna sudah login: tampilkan branding sebentar lalu ke Beranda
            b.btnPrimary.show(false); b.btnHaveAccount.show(false); b.btnSkip.show(false)
            handler.postDelayed(goMain, 1100)
            return
        }

        b.btnPrimary.setOnClickListener {
            when (page) {
                3 -> startActivity(Intent(this, RegisterActivity::class.java)) // belum punya akun -> registrasi
                else -> showPage(page + 1)
            }
        }
        b.btnHaveAccount.setOnClickListener { openLogin() }
        b.btnSkip.setOnClickListener { openLogin() }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (page > 0) showPage(page - 1) else finish()
            }
        })
    }

    private fun openLogin() {
        startActivity(Intent(this, LoginActivity::class.java))
    }

    private fun showPage(i: Int) {
        page = i
        pages.forEachIndexed { idx, v -> v.show(idx == i) }
        b.btnSkip.show(i in 1..2 || i == 3)
        b.pageTitle.text = titles[i]
        b.pageDesc.text = descs[i]
        b.pageTitle.show(i > 0)
        b.pageDesc.show(i > 0)
        b.dots.show(i > 0)
        b.btnPrimary.text = if (i == 0 || i == 3) "Mulai" else "Lanjut"
        b.btnHaveAccount.show(i == 0 || i == 3)
        for (d in 0 until b.dots.childCount) {
            (b.dots.getChildAt(d) as ImageView).setImageResource(if (d == i - 1) R.drawable.bg_dot_on else R.drawable.bg_dot_off)
        }
    }

    private fun buildDots() {
        val gap = (4 * resources.displayMetrics.density).toInt()
        repeat(3) {
            val iv = ImageView(this)
            iv.layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT)
                .also { lp -> lp.setMargins(gap, 0, gap, 0) }
            iv.importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
            b.dots.addView(iv)
        }
    }

    override fun onDestroy() {
        handler.removeCallbacks(goMain)
        super.onDestroy()
    }
}
