package com.example.ruangtunggu.ui.registration

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.os.Bundle
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import com.example.ruangtunggu.MainActivity
import com.example.ruangtunggu.ServiceLocator
import com.example.ruangtunggu.data.model.QueueDetail
import com.example.ruangtunggu.data.model.QueueStatus
import com.example.ruangtunggu.databinding.ActivityTicketBinding
import com.example.ruangtunggu.ui.common.applyStatusBadge
import com.example.ruangtunggu.ui.common.show
import com.example.ruangtunggu.utils.DateUtils
import com.example.ruangtunggu.utils.QueueMath
import com.google.zxing.BarcodeFormat
import com.google.zxing.qrcode.QRCodeWriter

/**
 * Pendaftaran berhasil (mode pendaftaran) dan Detail Antrean (mode detail dari Riwayat).
 * Nomor antrean berasal dari hasil proses pendaftaran yang tersimpan di database.
 */
class TicketActivity : AppCompatActivity() {

    private lateinit var b: ActivityTicketBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityTicketBinding.inflate(layoutInflater)
        setContentView(b.root)

        val detailMode = intent.getBooleanExtra(EXTRA_DETAIL_MODE, false)
        val queueId = intent.getLongExtra(EXTRA_QUEUE_ID, -1)
        val d: QueueDetail? = ServiceLocator.queues.detail(ServiceLocator.session.userId, queueId) // hanya milik pengguna ini
        if (d == null) { finish(); return }

        b.tvTitle.text = if (detailMode) "Detail Antrean" else "Pendaftaran berhasil"
        b.tvSubtitle.text = if (detailMode) "Informasi pendaftaran Anda" else "Simpan nomor antrean Anda"
        b.tvCode.text = d.queue.queueCode
        b.tvHospital.text = d.hospitalNama
        b.tvPoli.text = d.poliNama
        b.tvDoctor.text = d.doctorNama
        b.tvSchedule.text = "${DateUtils.shortLabel(d.queue.tanggal)} · ${d.jamMulai}"

        val serving = ServiceLocator.queues.servingFor(d.queue.poliId, d.queue.tanggal)
        val sisa = QueueMath.sisa(d.queue.queueNumber, serving)
        b.tvEstimate.text = "Sisa $sisa antrean · estimasi ${QueueMath.estimasiMenit(sisa)} menit"
        b.tvInfo.text = "Tunjukkan kode ini kepada petugas pendaftaran."

        b.tvStatus.show(detailMode)
        if (detailMode) b.tvStatus.applyStatusBadge(d.queue.status)

        // QR hanya berisi nomor antrean dan id (tanpa data pribadi)
        b.imgQr.setImageBitmap(qr("RT|${d.queue.queueCode}|${d.queue.queueId}"))

        val active = d.queue.status == QueueStatus.AKTIF
        b.btnMonitor.show(active)
        b.btnMonitor.setOnClickListener { goMain(MainActivity.TAB_QUEUE) }
        if (detailMode) {
            b.btnHome.text = "Tutup"
            b.btnHome.setOnClickListener { finish() }
        } else {
            b.btnHome.setOnClickListener { goMain(MainActivity.TAB_HOME) }
            // Back dari tiket kembali ke Beranda, bukan ke layar pendaftaran sebelumnya
            onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
                override fun handleOnBackPressed() { goMain(MainActivity.TAB_HOME) }
            })
        }
    }

    private fun goMain(tab: Int) {
        startActivity(
            Intent(this, MainActivity::class.java).putExtra(MainActivity.EXTRA_TAB, tab)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
        )
        finish()
    }

    private fun qr(text: String): Bitmap {
        val size = 512
        val m = QRCodeWriter().encode(text, BarcodeFormat.QR_CODE, size, size)
        val px = IntArray(size * size)
        for (y in 0 until size) for (x in 0 until size) px[y * size + x] = if (m.get(x, y)) Color.BLACK else Color.WHITE
        return Bitmap.createBitmap(px, size, size, Bitmap.Config.ARGB_8888)
    }

    companion object {
        const val EXTRA_QUEUE_ID = "queue_id"
        const val EXTRA_DETAIL_MODE = "detail_mode"
        fun intent(ctx: Context, queueId: Long, detailMode: Boolean): Intent =
            Intent(ctx, TicketActivity::class.java).putExtra(EXTRA_QUEUE_ID, queueId).putExtra(EXTRA_DETAIL_MODE, detailMode)
    }
}
