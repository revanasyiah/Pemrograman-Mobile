package com.example.ruangtunggu.data.repository

import com.example.ruangtunggu.data.model.*

/*
 * Antarmuka ini adalah titik pergantian backend. Implementasi saat ini: paket data.local (SQLite).
 * Untuk Firebase, buat FirebaseAuthRepository / FirestoreQueueRepository di paket data.remote
 * dan ganti pembuatannya di ServiceLocator. UI tidak perlu diubah.
 */

// ------------------------------------------------------------------ Autentikasi

data class RegisterForm(
    val nama: String,
    val contact: String, // email atau nomor HP
    val nik: String,
    val birth: String, // "Kota, DD/MM/YYYY"
    val password: String,
    val captchaChecked: Boolean
)

sealed class RegisterResult {
    data class Success(val user: User) : RegisterResult()
    /** key: nama | contact | nik | birth | password | captcha */
    data class Invalid(val errors: Map<String, String>) : RegisterResult()
    data class Duplicate(val field: String) : RegisterResult()
}

sealed class LoginResult {
    data class Success(val user: User) : LoginResult()
    object EmptyField : LoginResult()
    object CaptchaRequired : LoginResult()
    object WrongCredential : LoginResult()
}

sealed class ResetRequestResult {
    /** [code] hanya untuk mode demo (tidak ada email/SMS sungguhan). */
    data class Sent(val code: String, val maskedContact: String) : ResetRequestResult()
    object NotFound : ResetRequestResult()
    object EmptyField : ResetRequestResult()
}

sealed class VerifyResult {
    object Valid : VerifyResult()
    data class Invalid(val attemptsLeft: Int) : VerifyResult()
    object Expired : VerifyResult()
    object TooManyAttempts : VerifyResult()
    object NoRequest : VerifyResult()
}

sealed class ResetResult {
    object Success : ResetResult()
    object WeakPassword : ResetResult()
    object Mismatch : ResetResult()
    object NotVerified : ResetResult()
}

data class ProfileForm(
    val nama: String,
    val nik: String,
    val birth: String, // dd/MM/yyyy
    val gender: String?,
    val phone: String
)

sealed class ProfileResult {
    data class Success(val user: User) : ProfileResult()
    /** key: nama | nik | birth | gender | phone */
    data class Invalid(val errors: Map<String, String>) : ProfileResult()
}

interface AuthRepository {
    fun register(form: RegisterForm): RegisterResult
    fun login(identity: String, password: String, captchaChecked: Boolean): LoginResult
    fun logout()
    fun currentUser(): User?
    fun getUser(userId: Long): User?
    fun updateProfile(userId: Long, form: ProfileForm): ProfileResult

    fun requestPasswordReset(identity: String): ResetRequestResult
    fun verifyResetCode(code: String): VerifyResult
    fun resetPassword(newPassword: String, confirm: String): ResetResult
}

// ------------------------------------------------------------------ Rumah sakit & jadwal

interface HospitalRepository {
    fun allHospitals(): List<HospitalWithPolis>
    fun getHospital(hospitalId: Long): Hospital?
    fun polisOf(hospitalId: Long): List<Poli>
    fun getPoli(poliId: Long): Poli?
    /** Dokter yang punya jadwal pada [tanggal]; kosong => "Jadwal belum tersedia". */
    fun doctorSchedules(poliId: Long, tanggal: String): List<DoctorSchedule>
    fun scheduleDetail(scheduleId: Long): ScheduleDetail?
}

// ------------------------------------------------------------------ Antrean

sealed class RegisterQueueResult {
    data class Success(val detail: QueueDetail) : RegisterQueueResult()
    object SlotFull : RegisterQueueResult()
    data class Duplicate(val detail: QueueDetail) : RegisterQueueResult()
    object NotFound : RegisterQueueResult()
}

sealed class CancelResult {
    object Success : CancelResult()
    object NotActive : CancelResult()
    object NotFound : CancelResult()
}

interface QueueRepository {
    /** Pemeriksaan slot + penerbitan nomor + simpan + kurangi kuota, dalam satu transaksi atomik. */
    fun register(userId: Long, scheduleId: Long): RegisterQueueResult
    fun cancel(userId: Long, queueId: Long): CancelResult
    fun detail(userId: Long, queueId: Long): QueueDetail?
    fun history(userId: Long, status: String): List<QueueDetail>
    fun monitor(userId: Long): MonitorState?
    /** Mode demo: petugas memanggil nomor berikutnya pada poli+tanggal tersebut. Mengembalikan nomor baru. */
    fun officerCallNext(poliId: Long, tanggal: String): Int
    fun servingFor(poliId: Long, tanggal: String): Int
    fun activeQueues(userId: Long): List<QueueDetail>
    /** Sinkronkan status: antrean yang sudah terlewati atau kedaluwarsa menjadi Selesai. */
    fun syncStatuses(userId: Long)

    // pencatatan notifikasi (dipakai QueueMonitorService)
    fun notifLog(queueId: Long): NotifLogRow?
    fun saveNotifLog(row: NotifLogRow)
    fun sentNotifications(userId: Long): List<NotificationItem>
}

data class NotifLogRow(
    val queueId: Long,
    val status: String,
    val attempts: Int,
    val nextRetryAt: Long,
    val message: String,
    val sisa: Int,
    val createdAt: Long,
    val sentAt: Long?
)
