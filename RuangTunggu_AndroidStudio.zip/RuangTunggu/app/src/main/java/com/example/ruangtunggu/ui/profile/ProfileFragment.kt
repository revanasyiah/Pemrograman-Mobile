package com.example.ruangtunggu.ui.profile

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.activity.result.contract.ActivityResultContracts
import androidx.fragment.app.Fragment
import com.example.ruangtunggu.R
import com.example.ruangtunggu.ServiceLocator
import com.example.ruangtunggu.databinding.FragmentProfileBinding
import com.example.ruangtunggu.databinding.ItemProfileRowBinding
import com.example.ruangtunggu.ui.auth.LoginActivity
import com.example.ruangtunggu.ui.common.DialogKind
import com.example.ruangtunggu.ui.common.StatusDialog
import com.example.ruangtunggu.ui.common.show
import com.example.ruangtunggu.utils.DateUtils
import com.example.ruangtunggu.utils.Validators

/** Profil Saya (flowchart hal. 2): tampilkan data profil -> Ubah Profil. NIK dan No. HP ditampilkan tersamar. */
class ProfileFragment : Fragment() {

    private var _b: FragmentProfileBinding? = null
    private val b get() = _b!!
    private val handler = Handler(Looper.getMainLooper())

    private val editLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        if (r.resultCode == android.app.Activity.RESULT_OK && _b != null) {
            b.bannerSuccess.show(true)
            handler.postDelayed({ _b?.bannerSuccess?.show(false) }, 3000)
        }
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _b = FragmentProfileBinding.inflate(inflater, container, false)
        return b.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        b.btnEdit.setOnClickListener { editLauncher.launch(Intent(requireContext(), EditProfileActivity::class.java)) }
        b.btnLogout.setOnClickListener {
            StatusDialog.show(
                requireContext(), DialogKind.WARNING, "Keluar dari akun?",
                "Anda perlu masuk kembali untuk memakai aplikasi.",
                positive = "Ya, keluar", negative = "Batal", danger = true,
                onPositive = {
                    ServiceLocator.auth.logout()
                    startActivity(Intent(requireContext(), LoginActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK))
                }
            )
        }
    }

    override fun onResume() {
        super.onResume()
        val u = ServiceLocator.auth.currentUser() ?: return
        b.tvAvatar.text = DateUtils.initials(u.nama)
        b.tvName.text = u.nama
        b.profileRows.removeAllViews()
        addRow(R.drawable.ic_id_card, "NIK", Validators.maskNik(u.nik, 'x'))
        addRow(R.drawable.ic_calendar, "Tanggal lahir", DateUtils.birthLabel(u.tanggalLahir))
        addRow(R.drawable.ic_person, "Jenis kelamin", u.jenisKelamin ?: "Belum diisi")
        addRow(R.drawable.ic_phone, "No. HP", u.nomorHp?.let { Validators.maskPhone(it) } ?: "Belum diisi")
        addRow(R.drawable.ic_mail, "Email", u.email ?: "-")
    }

    private fun addRow(icon: Int, label: String, value: String) {
        val row = ItemProfileRowBinding.inflate(layoutInflater, b.profileRows, false)
        row.rowIcon.setImageResource(icon)
        row.rowLabel.text = label
        row.rowValue.text = value
        b.profileRows.addView(row.root)
    }

    override fun onDestroyView() {
        handler.removeCallbacksAndMessages(null)
        _b = null
        super.onDestroyView()
    }
}
