package com.example.ruangtunggu.data.local

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteConstraintException
import com.example.ruangtunggu.data.model.User
import com.example.ruangtunggu.data.repository.*
import com.example.ruangtunggu.utils.AppConfig
import com.example.ruangtunggu.utils.PasswordHasher
import com.example.ruangtunggu.utils.Validators
import java.security.SecureRandom

/** Sesi login: hanya menyimpan userId (bukan kata sandi atau data sensitif). */
class SessionManager(ctx: Context) {
    private val prefs = ctx.applicationContext.getSharedPreferences("session", Context.MODE_PRIVATE)
    var userId: Long
        get() = prefs.getLong("user_id", -1L)
        set(v) { prefs.edit().putLong("user_id", v).apply() }
    fun isLoggedIn() = userId > 0
    fun clear() { prefs.edit().remove("user_id").apply() }

    /** Flag mode demo: paksa pengiriman notifikasi gagal untuk menguji jalur coba-ulang. */
    var simulateSendFailure: Boolean
        get() = prefs.getBoolean("demo_fail_send", false)
        set(v) { prefs.edit().putBoolean("demo_fail_send", v).apply() }
}

class LocalAuthRepository(private val database: AppDatabase, private val session: SessionManager) : AuthRepository {

    private val db get() = database.writableDatabase

    private class PendingReset(val userId: Long, val code: String, val expiresAt: Long) {
        var attempts = 0
        var verified = false
    }

    private var pending: PendingReset? = null

    // ------------------------------------------------------------ registrasi (flowchart hal. 1)

    override fun register(form: RegisterForm): RegisterResult {
        val errors = LinkedHashMap<String, String>()
        val nama = form.nama.trim()
        val contact = form.contact.trim()
        val nik = form.nik.trim()

        if (!Validators.isValidName(nama)) errors["nama"] = "Nama lengkap minimal 3 karakter"
        val isEmail = Validators.isEmail(contact)
        val isPhone = !isEmail && Validators.isPhone(contact)
        if (!isEmail && !isPhone) errors["contact"] = "Masukkan email atau nomor HP yang valid"
        if (!Validators.isNik(nik)) errors["nik"] = "NIK harus 16 digit angka"
        val birth = Validators.parseBirth(form.birth)
        if (birth == null) errors["birth"] = "Format: Kota, DD/MM/YYYY"
        if (!Validators.isStrongPassword(form.password)) errors["password"] = "Minimal 8 karakter, kombinasi huruf dan angka"
        if (!form.captchaChecked) errors["captcha"] = "Centang verifikasi terlebih dahulu"
        if (errors.isNotEmpty()) return RegisterResult.Invalid(errors)

        val email = if (isEmail) contact.lowercase() else null
        val phone = if (isPhone) Validators.normalizePhone(contact) else null

        // Keunikan email/HP/NIK
        if (email != null && exists("email", email)) return RegisterResult.Duplicate("email")
        if (phone != null && exists("nomor_hp", phone)) return RegisterResult.Duplicate("nomor_hp")
        if (exists("nik", nik)) return RegisterResult.Duplicate("nik")

        val salt = PasswordHasher.newSalt()
        val cv = ContentValues().apply {
            put("nama", nama); put("email", email); put("nomor_hp", phone); put("nik", nik)
            put("tempat_lahir", birth!!.first); put("tanggal_lahir", birth.second)
            put("pass_hash", PasswordHasher.hash(form.password, salt)); put("pass_salt", salt)
        }
        return try {
            val id = db.insertOrThrow("users", null, cv)
            RegisterResult.Success(getUser(id)!!)
        } catch (e: SQLiteConstraintException) {
            RegisterResult.Duplicate("akun")
        }
    }

    private fun exists(column: String, value: String, exceptUserId: Long = -1): Boolean =
        db.rawQuery("SELECT 1 FROM users WHERE $column=? AND user_id<>? LIMIT 1", arrayOf(value, exceptUserId.toString()))
            .use { it.moveToFirst() }

    // ------------------------------------------------------------ login (flowchart hal. 1)

    override fun login(identity: String, password: String, captchaChecked: Boolean): LoginResult {
        val id = identity.trim()
        if (id.isEmpty() || password.isEmpty()) return LoginResult.EmptyField
        if (!captchaChecked) return LoginResult.CaptchaRequired
        val (col, value) = if (id.contains('@')) "email" to id.lowercase() else "nik" to id
        db.rawQuery("SELECT user_id, pass_hash, pass_salt FROM users WHERE $col=?", arrayOf(value)).use { c ->
            if (!c.moveToFirst()) {
                // Hash tiruan agar waktu respons tidak membedakan akun ada/tidak
                PasswordHasher.hash(password, PasswordHasher.newSalt())
                return LoginResult.WrongCredential
            }
            val ok = PasswordHasher.verify(password, c.getString(2), c.getString(1))
            if (!ok) return LoginResult.WrongCredential
            val uid = c.getLong(0)
            session.userId = uid
            return LoginResult.Success(getUser(uid)!!)
        }
    }

    override fun logout() { session.clear(); pending = null }

    override fun currentUser(): User? = if (session.isLoggedIn()) getUser(session.userId) else null

    override fun getUser(userId: Long): User? =
        db.rawQuery(
            "SELECT user_id,nama,email,nomor_hp,nik,tempat_lahir,tanggal_lahir,jenis_kelamin FROM users WHERE user_id=?",
            arrayOf(userId.toString())
        ).use { if (it.moveToFirst()) it.toUser() else null }

    private fun Cursor.toUser() = User(
        userId = getLong(0), nama = getString(1), email = getString(2), nomorHp = getString(3),
        nik = getString(4), tempatLahir = getString(5), tanggalLahir = getString(6), jenisKelamin = getString(7)
    )

    // ------------------------------------------------------------ ubah profil (flowchart hal. 2)

    override fun updateProfile(userId: Long, form: ProfileForm): ProfileResult {
        val errors = LinkedHashMap<String, String>()
        val nik = form.nik.trim()
        val phone = Validators.normalizePhone(form.phone.trim())
        if (!Validators.isValidName(form.nama)) errors["nama"] = "Data tidak valid"
        if (!Validators.isNik(nik) || exists("nik", nik, userId)) errors["nik"] = "Data tidak valid"
        val iso = Validators.parseDate(form.birth)
        if (iso == null) errors["birth"] = "Data tidak valid"
        if (form.gender != "Laki-laki" && form.gender != "Perempuan") errors["gender"] = "Data tidak valid"
        if (!Validators.isPhone(phone) || exists("nomor_hp", phone, userId)) errors["phone"] = "Data tidak valid"
        if (errors.isNotEmpty()) return ProfileResult.Invalid(errors)

        val cv = ContentValues().apply {
            put("nama", form.nama.trim()); put("nik", nik); put("tanggal_lahir", iso)
            put("jenis_kelamin", form.gender); put("nomor_hp", phone)
        }
        return try {
            db.update("users", cv, "user_id=?", arrayOf(userId.toString()))
            ProfileResult.Success(getUser(userId)!!)
        } catch (e: SQLiteConstraintException) {
            ProfileResult.Invalid(mapOf("nik" to "Data tidak valid"))
        }
    }

    // ------------------------------------------------------------ lupa kata sandi (MODE DEMO)

    override fun requestPasswordReset(identity: String): ResetRequestResult {
        val id = identity.trim()
        if (id.isEmpty()) return ResetRequestResult.EmptyField
        val (col, value) = if (id.contains('@')) "email" to id.lowercase() else "nik" to id
        db.rawQuery("SELECT user_id, email, nomor_hp FROM users WHERE $col=?", arrayOf(value)).use { c ->
            if (!c.moveToFirst()) { pending = null; return ResetRequestResult.NotFound }
            val code = "%0${AppConfig.OTP_LENGTH}d".format(SecureRandom().nextInt(1_000_000))
            pending = PendingReset(c.getLong(0), code, System.currentTimeMillis() + AppConfig.OTP_TTL_MS)
            val contact = c.getString(1) ?: c.getString(2) ?: ""
            return ResetRequestResult.Sent(code, Validators.maskContact(contact))
        }
    }

    override fun verifyResetCode(code: String): VerifyResult {
        val p = pending ?: return VerifyResult.NoRequest
        if (System.currentTimeMillis() > p.expiresAt) { pending = null; return VerifyResult.Expired }
        if (p.attempts >= AppConfig.OTP_MAX_ATTEMPTS) return VerifyResult.TooManyAttempts
        return if (code == p.code) {
            p.verified = true
            VerifyResult.Valid
        } else {
            p.attempts++
            if (p.attempts >= AppConfig.OTP_MAX_ATTEMPTS) VerifyResult.TooManyAttempts
            else VerifyResult.Invalid(AppConfig.OTP_MAX_ATTEMPTS - p.attempts)
        }
    }

    override fun resetPassword(newPassword: String, confirm: String): ResetResult {
        val p = pending
        if (p == null || !p.verified) return ResetResult.NotVerified
        if (!Validators.isStrongPassword(newPassword)) return ResetResult.WeakPassword
        if (newPassword != confirm) return ResetResult.Mismatch
        val salt = PasswordHasher.newSalt()
        val cv = ContentValues().apply {
            put("pass_hash", PasswordHasher.hash(newPassword, salt)); put("pass_salt", salt)
        }
        db.update("users", cv, "user_id=?", arrayOf(p.userId.toString()))
        pending = null
        return ResetResult.Success
    }
}
