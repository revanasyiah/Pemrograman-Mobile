package com.example.ruangtunggu.ui.history

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.ruangtunggu.R
import com.example.ruangtunggu.ServiceLocator
import com.example.ruangtunggu.data.model.QueueDetail
import com.example.ruangtunggu.data.model.QueueStatus
import com.example.ruangtunggu.data.repository.CancelResult
import com.example.ruangtunggu.databinding.FragmentHistoryBinding
import com.example.ruangtunggu.databinding.ItemQueueHistoryBinding
import com.example.ruangtunggu.ui.common.DialogKind
import com.example.ruangtunggu.ui.common.StatusDialog
import com.example.ruangtunggu.ui.common.applyStatusBadge
import com.example.ruangtunggu.ui.common.bind
import com.example.ruangtunggu.ui.common.show
import com.example.ruangtunggu.ui.registration.TicketActivity
import com.example.ruangtunggu.utils.DateUtils

/**
 * Riwayat antrean (Aktif/Selesai/Batal) + pembatalan (flowchart hal. 8).
 * Pembatalan: konfirmasi -> cek status Aktif -> ubah ke Batal & kembalikan kuota -> pesan hasil.
 */
class HistoryFragment : Fragment() {

    private var _b: FragmentHistoryBinding? = null
    private val b get() = _b!!
    private var status = QueueStatus.AKTIF
    private val adapter = HistoryAdapter(::openDetail, ::askCancel)
    private var cancelling = false

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _b = FragmentHistoryBinding.inflate(inflater, container, false)
        return b.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        b.header.bind("Riwayat Antrean", "Semua pendaftaran Anda", null)
        b.rvHistory.layoutManager = LinearLayoutManager(requireContext())
        b.rvHistory.adapter = adapter
        b.tabAktif.setOnClickListener { setStatus(QueueStatus.AKTIF) }
        b.tabSelesai.setOnClickListener { setStatus(QueueStatus.SELESAI) }
        b.tabBatal.setOnClickListener { setStatus(QueueStatus.BATAL) }
    }

    override fun onResume() {
        super.onResume()
        load()
    }

    private fun setStatus(s: String) { status = s; load() }

    private fun load() {
        b.tabAktif.isSelected = status == QueueStatus.AKTIF
        b.tabSelesai.isSelected = status == QueueStatus.SELESAI
        b.tabBatal.isSelected = status == QueueStatus.BATAL
        // Hanya milik pengguna yang sedang login
        val items = ServiceLocator.queues.history(ServiceLocator.session.userId, status)
        adapter.submit(items)
        b.tvEmptyHistory.show(items.isEmpty())
        b.tvEmptyHistory.text = "Belum ada antrean berstatus ${status.lowercase()}."
    }

    private fun openDetail(d: QueueDetail) {
        startActivity(TicketActivity.intent(requireContext(), d.queue.queueId, detailMode = true))
    }

    private fun askCancel(d: QueueDetail) {
        if (cancelling) return
        StatusDialog.show(
            requireContext(), DialogKind.WARNING, "Batalkan antrean?",
            "Antrean ${d.queue.queueCode} akan dibatalkan dan kuota slot dikembalikan.",
            positive = "Ya, batalkan", negative = "Tidak", danger = true,
            onPositive = { doCancel(d) }
        )
    }

    private fun doCancel(d: QueueDetail) {
        if (cancelling) return
        cancelling = true // cegah proses ganda akibat ketukan berulang
        try {
            val ctx = requireContext()
            when (ServiceLocator.queues.cancel(ServiceLocator.session.userId, d.queue.queueId)) {
                CancelResult.Success -> StatusDialog.show(
                    ctx, DialogKind.SUCCESS, "Antrean berhasil dibatalkan",
                    "Antrean ${d.queue.queueCode} telah dibatalkan dan kuota slot sudah dikembalikan.", positive = "Selesai"
                )
                CancelResult.NotActive, CancelResult.NotFound -> StatusDialog.show(
                    ctx, DialogKind.ERROR, "Antrean tidak dapat dibatalkan",
                    "Status antrean sudah tidak aktif atau sedang dilayani petugas.", positive = "Mengerti", positiveOutline = true
                )
            }
            load()
        } finally {
            cancelling = false
        }
    }

    override fun onDestroyView() {
        _b = null
        super.onDestroyView()
    }
}

class HistoryAdapter(
    private val onClick: (QueueDetail) -> Unit,
    private val onCancel: (QueueDetail) -> Unit
) : RecyclerView.Adapter<HistoryAdapter.VH>() {

    private var items: List<QueueDetail> = emptyList()

    fun submit(list: List<QueueDetail>) { items = list; notifyDataSetChanged() }

    class VH(val b: ItemQueueHistoryBinding) : RecyclerView.ViewHolder(b.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        VH(ItemQueueHistoryBinding.inflate(LayoutInflater.from(parent.context), parent, false))

    override fun getItemCount() = items.size

    override fun onBindViewHolder(holder: VH, position: Int) {
        val d = items[position]
        val b = holder.b
        val ctx = b.root.context
        b.tvHospital.text = d.hospitalNama
        b.tvBadge.applyStatusBadge(d.queue.status)
        b.tvDetail.text = "Poli ${d.poliNama} · ${DateUtils.shortLabel(d.queue.tanggal)} · ${d.jamMulai}"
        b.tvCode.text = d.queue.queueCode
        val active = d.queue.status == QueueStatus.AKTIF
        b.tvCode.setTextColor(ContextCompat.getColor(ctx, if (active) R.color.teal_900 else R.color.slate_400))
        b.btnCancel.show(active)
        b.btnCancel.setOnClickListener { onCancel(d) }
        b.root.setOnClickListener { onClick(d) }
    }
}
