package com.example.ruangtunggu.ui.auth

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.ruangtunggu.ServiceLocator
import com.example.ruangtunggu.data.repository.ResetRequestResult
import com.example.ruangtunggu.databinding.ActivityForgotPasswordBinding
import com.example.ruangtunggu.ui.common.InputState
import com.example.ruangtunggu.ui.common.bind
import com.example.ruangtunggu.ui.common.show

/** Lupa kata sandi, langkah 1: identitas akun -> sistem memulai verifikasi (MODE DEMO, tanpa email/SMS nyata). */
class ForgotPasswordActivity : AppCompatActivity() {

    private lateinit var b: ActivityForgotPasswordBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityForgotPasswordBinding.inflate(layoutInflater)
        setContentView(b.root)
        b.header.bind("Lupa Kata Sandi", "Pulihkan akses akun Anda") { finish() }
        b.btnBackLogin.setOnClickListener { finish() }
        b.btnSend.setOnClickListener { send() }
    }

    private fun send() {
        b.banner.root.show(false)
        b.inIdentity.setState(InputState.NORMAL)
        val identity = b.inIdentity.text
        when (val r = ServiceLocator.auth.requestPasswordReset(identity)) {
            is ResetRequestResult.Sent -> startActivity(
                Intent(this, VerifyCodeActivity::class.java)
                    .putExtra(VerifyCodeActivity.EXTRA_IDENTITY, identity)
                    .putExtra(VerifyCodeActivity.EXTRA_DEMO_CODE, r.code)
                    .putExtra(VerifyCodeActivity.EXTRA_MASKED, r.maskedContact)
            )
            ResetRequestResult.NotFound -> {
                b.inIdentity.setState(InputState.ERROR)
                b.banner.bannerText.text = "Akun tidak ditemukan"
                b.banner.root.show(true)
            }
            ResetRequestResult.EmptyField -> {
                b.inIdentity.setState(InputState.ERROR)
                b.banner.bannerText.text = "NIK atau email wajib diisi"
                b.banner.root.show(true)
            }
        }
    }
}
