package com.example.ruangtunggu.ui.common

import android.content.Context
import android.text.InputFilter
import android.text.InputType
import android.util.AttributeSet
import android.view.Gravity
import android.view.LayoutInflater
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import androidx.core.content.ContextCompat
import androidx.core.content.res.use
import com.example.ruangtunggu.R

enum class InputState { NORMAL, SUCCESS, ERROR }

/** Kolom input berbentuk rounded dengan ikon di kiri dan indikator status di kanan (sesuai wireframe). */
class IconInput @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : LinearLayout(context, attrs, defStyleAttr) {

    val editText: EditText
    private val iconView: ImageView
    private val stateView: ImageView
    private var state = InputState.NORMAL

    init {
        orientation = HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        val pad = (12 * resources.displayMetrics.density).toInt()
        setPadding(pad, 0, pad, 0)
        LayoutInflater.from(context).inflate(R.layout.view_icon_input, this, true)
        editText = findViewById(R.id.inputEdit)
        iconView = findViewById(R.id.inputIcon)
        stateView = findViewById(R.id.inputState)
        // Beberapa IconInput memakai id anak yang sama; nonaktifkan save-state agar tidak saling menimpa.
        editText.isSaveEnabled = false

        context.obtainStyledAttributes(attrs, R.styleable.IconInput).use { a ->
            a.getResourceId(R.styleable.IconInput_iconSrc, 0).takeIf { it != 0 }?.let { iconView.setImageResource(it) }
            editText.hint = a.getString(R.styleable.IconInput_hintText)
            val max = a.getInt(R.styleable.IconInput_maxLen, 0)
            if (max > 0) editText.filters = arrayOf(InputFilter.LengthFilter(max))
            editText.inputType = when (a.getInt(R.styleable.IconInput_kind, 0)) {
                1 -> InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS
                2 -> InputType.TYPE_CLASS_NUMBER
                3 -> InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
                4 -> InputType.TYPE_CLASS_PHONE
                else -> InputType.TYPE_CLASS_TEXT
            }
        }
        editText.setOnFocusChangeListener { _, _ -> applyBackground() }
        applyBackground()
    }

    var text: String
        get() = editText.text.toString()
        set(value) { editText.setText(value) }

    fun setState(newState: InputState) {
        state = newState
        when (newState) {
            InputState.SUCCESS -> {
                stateView.setImageResource(R.drawable.ic_check_circle)
                stateView.setColorFilter(ContextCompat.getColor(context, R.color.primary))
                stateView.visibility = VISIBLE
                iconView.setColorFilter(ContextCompat.getColor(context, R.color.primary))
            }
            InputState.ERROR -> {
                stateView.setImageResource(R.drawable.ic_error)
                stateView.setColorFilter(ContextCompat.getColor(context, R.color.danger))
                stateView.visibility = VISIBLE
                iconView.setColorFilter(ContextCompat.getColor(context, R.color.danger))
            }
            InputState.NORMAL -> {
                stateView.visibility = GONE
                iconView.setColorFilter(ContextCompat.getColor(context, R.color.slate_500))
            }
        }
        applyBackground()
    }

    private fun applyBackground() {
        setBackgroundResource(
            when {
                state == InputState.ERROR -> R.drawable.bg_input_error
                state == InputState.SUCCESS -> R.drawable.bg_input_success
                editText.hasFocus() -> R.drawable.bg_input_focus
                else -> R.drawable.bg_input
            }
        )
    }

    override fun setEnabled(enabled: Boolean) {
        super.setEnabled(enabled)
        editText.isEnabled = enabled
    }
}
