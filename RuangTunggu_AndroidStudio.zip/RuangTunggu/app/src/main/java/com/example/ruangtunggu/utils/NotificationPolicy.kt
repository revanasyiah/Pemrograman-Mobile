package com.example.ruangtunggu.utils

/** Status pencatatan notifikasi per antrean (satu baris per antrean => tidak ada notifikasi ganda). */
object NotifStatus {
    const val SENT = "SENT"
    const val RETRY = "RETRY"
    const val FAILED = "FAILED"
}

enum class NotifDecision { SKIP, SEND }

/**
 * Logika keputusan notifikasi yang terpisah dari pengiriman (flowchart hal. 7).
 * - log == null  : belum pernah dicoba -> kirim jika sisa <= batas
 * - status RETRY : kirim ulang jika waktu coba ulang sudah tiba
 * - SENT/FAILED  : lewati (tidak ada pengiriman berulang)
 */
object NotificationPolicy {
    fun decide(sisa: Int, threshold: Int, status: String?, nextRetryAt: Long, now: Long): NotifDecision {
        if (!QueueMath.shouldNotify(sisa, threshold)) return NotifDecision.SKIP
        return when (status) {
            null -> NotifDecision.SEND
            NotifStatus.RETRY -> if (now >= nextRetryAt) NotifDecision.SEND else NotifDecision.SKIP
            else -> NotifDecision.SKIP
        }
    }
}
