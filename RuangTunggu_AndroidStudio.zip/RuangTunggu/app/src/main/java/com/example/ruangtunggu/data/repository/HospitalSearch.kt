package com.example.ruangtunggu.data.repository

import com.example.ruangtunggu.data.model.HospitalWithPolis

/** Pencarian RS & poli (flowchart hal. 3). Logika murni agar mudah diuji. */
object HospitalSearch {
    /** Chip filter pada wireframe: Semua, RS Umum, Poli Anak, Kandungan. */
    val FILTERS = listOf("Semua", "RS Umum", "Poli Anak", "Kandungan")

    /** Nama poli yang diwakili chip filter, atau null untuk "Semua". */
    fun poliOfFilter(filter: String): String? = when (filter) {
        "RS Umum" -> "Umum"
        "Poli Anak" -> "Anak"
        "Kandungan" -> "Kandungan"
        else -> null
    }

    fun filter(all: List<HospitalWithPolis>, query: String, filter: String): List<HospitalWithPolis> {
        val q = query.trim().lowercase()
        val poliFilter = poliOfFilter(filter)
        return all.filter { hw ->
            val byFilter = poliFilter == null || hw.polis.any { it.namaPoli.equals(poliFilter, ignoreCase = true) }
            val byQuery = q.isEmpty() ||
                hw.hospital.nama.lowercase().contains(q) ||
                hw.polis.any { it.namaPoli.lowercase().contains(q) || it.label.lowercase().contains(q) }
            byFilter && byQuery
        }
    }

    /** Poli yang cocok dengan kata kunci/filter, dipakai untuk pra-pilih di layar Pilih Poli. */
    fun poliHint(query: String, filter: String): String =
        poliOfFilter(filter) ?: query.trim()
}
