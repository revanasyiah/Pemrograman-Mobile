package com.example.ruangtunggu.ui.home

import android.graphics.Typeface
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.content.ContextCompat
import com.example.ruangtunggu.R
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.Fragment
import com.example.ruangtunggu.MainActivity
import com.example.ruangtunggu.ServiceLocator
import com.example.ruangtunggu.databinding.FragmentHomeBinding
import com.example.ruangtunggu.databinding.ItemHospitalMiniBinding
import com.example.ruangtunggu.ui.common.hospitalPhoto
import com.example.ruangtunggu.ui.common.show
import com.example.ruangtunggu.ui.hospital.SearchHospitalActivity
import com.example.ruangtunggu.ui.hospital.SelectPoliActivity
import com.example.ruangtunggu.utils.DateUtils
import com.example.ruangtunggu.utils.Validators
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/** Beranda (wireframe Beranda.svg): sapaan, pencarian, kartu antrean aktif, layanan, poli populer, RS terdekat. */
class HomeFragment : Fragment() {

    private var _b: FragmentHomeBinding? = null
    private val b get() = _b!!

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _b = FragmentHomeBinding.inflate(inflater, container, false)
        return b.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        val ctx = requireContext()
        val main = requireActivity() as MainActivity

        b.searchBar.setOnClickListener { startActivity(SearchHospitalActivity.intent(ctx)) }
        b.svcSearch.setOnClickListener { startActivity(SearchHospitalActivity.intent(ctx)) }
        b.svcSchedule.setOnClickListener { startActivity(SearchHospitalActivity.intent(ctx)) }
        b.svcHistory.setOnClickListener { main.selectTab(MainActivity.TAB_HISTORY) }
        b.svcProfile.setOnClickListener { main.selectTab(MainActivity.TAB_PROFILE) }
        b.tvSeeAll.setOnClickListener { startActivity(SearchHospitalActivity.intent(ctx)) }
        b.btnPantau.setOnClickListener { main.selectTab(MainActivity.TAB_QUEUE) }
        b.btnNewQueue.setOnClickListener { startActivity(SearchHospitalActivity.intent(ctx)) }
        b.btnBell.setOnClickListener { showNotifications() }

        // Poli populer -> pencarian dengan kata kunci poli tersebut
        val dp = resources.displayMetrics.density
        for (name in listOf("Umum", "Anak", "Gigi", "Kandungan")) {
            val chip = TextView(ctx).apply {
                text = name
                textSize = 12f
                setTypeface(typeface, Typeface.BOLD)
                setTextColor(ContextCompat.getColor(ctx, R.color.slate_700))
                setBackgroundResource(R.drawable.bg_chip_order)
                setPadding((16 * dp).toInt(), (9 * dp).toInt(), (16 * dp).toInt(), (9 * dp).toInt())
                layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT)
                    .also { it.rightMargin = (8 * dp).toInt() }
                setOnClickListener { startActivity(SearchHospitalActivity.intent(ctx, query = name)) }
            }
            b.popularRow.addView(chip)
        }

        // Rumah sakit terdekat (dua pertama dari data demo)
        for (hw in ServiceLocator.hospitals.allHospitals().take(3)) {
            val mini = ItemHospitalMiniBinding.inflate(layoutInflater, b.nearbyRow, false)
            mini.miniName.text = hw.hospital.nama
            mini.miniMeta.text = "★ %.1f · %.1f km".format(Locale.US, hw.hospital.rating, hw.hospital.jarakKm)
            hospitalPhoto(hw.hospital.foto)?.let {
                mini.miniPhoto.setPadding(0, 0, 0, 0)
                mini.miniPhoto.imageTintList = null
                mini.miniPhoto.setImageResource(it)
            }
            mini.root.setOnClickListener { startActivity(SelectPoliActivity.intent(ctx, hw.hospital.hospitalId)) }
            b.nearbyRow.addView(mini.root)
        }
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun refresh() {
        val user = ServiceLocator.auth.currentUser() ?: return
        b.tvAvatar.text = DateUtils.initials(user.nama)
        b.tvGreeting.text = DateUtils.greeting(Calendar.getInstance().get(Calendar.HOUR_OF_DAY)) + " 👋"
        b.tvName.text = user.nama

        val m = ServiceLocator.queues.monitor(user.userId)
        b.activeBlock.show(m != null)
        b.emptyBlock.show(m == null)
        if (m != null) {
            val d = m.detail
            b.tvQueueDate.text = DateUtils.shortLabel(d.queue.tanggal) + " · " + d.jamMulai
            b.tvQueueCode.text = d.queue.queueCode
            b.tvServing.text = m.servingCode
            b.tvQueueSub.text = "Poli ${d.poliNama} · ${d.hospitalNama}"
            b.progressQueue.progress = com.example.ruangtunggu.utils.QueueMath.progress(d.queue.queueNumber, m.serving)
            b.tvQueueSisa.text = if (m.giliranTiba) "Giliran Anda sedang dilayani"
            else "Sisa ${m.sisa} antrean · estimasi ${m.estimasiMenit} menit"
        }
        b.bellDot.show(ServiceLocator.queues.sentNotifications(user.userId).isNotEmpty())
    }

    private fun showNotifications() {
        val user = ServiceLocator.auth.currentUser() ?: return
        val items = ServiceLocator.queues.sentNotifications(user.userId)
        val fmt = SimpleDateFormat("dd/MM HH:mm", Locale("id", "ID"))
        val text = if (items.isEmpty()) "Belum ada notifikasi.\nPemberitahuan muncul saat sisa antrean ≤ ${com.example.ruangtunggu.utils.AppConfig.NOTIF_THRESHOLD}."
        else items.joinToString("\n\n") { "Giliran Anda sudah dekat (${it.queueCode})\n${it.message}\n${fmt.format(Date(it.sentAt))}" }
        AlertDialog.Builder(requireContext()).setTitle("Notifikasi").setMessage(text).setPositiveButton("Tutup", null).show()
    }

    override fun onDestroyView() {
        _b = null
        super.onDestroyView()
    }
}
