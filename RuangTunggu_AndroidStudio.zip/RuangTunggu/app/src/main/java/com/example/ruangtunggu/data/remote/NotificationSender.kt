package com.example.ruangtunggu.data.remote

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.example.ruangtunggu.MainActivity
import com.example.ruangtunggu.R
import com.example.ruangtunggu.data.local.SessionManager
import com.example.ruangtunggu.data.model.QueueDetail

/**
 * Pemisah antara "kapan notifikasi dikirim" (QueueMonitorService) dan "bagaimana dikirim".
 *
 * Implementasi saat ini: [LocalNotificationSender] = notifikasi lokal di perangkat ini (MODE DEMO).
 * FCM (Firebase Cloud Messaging) BELUM dikonfigurasi di project ini. Untuk memakai FCM, backend (mis. Cloud Functions)
 * mengirim pesan ke token perangkat, dan implementasi interface ini dapat diganti. Lihat README bagian Firebase.
 */
interface NotificationSender {
    /** @return true jika pesan berhasil diserahkan ke pengguna; false jika gagal (akan dijadwalkan ulang). */
    fun send(detail: QueueDetail, sisa: Int, message: String): Boolean
}

class LocalNotificationSender(
    private val context: Context,
    private val session: SessionManager
) : NotificationSender {

    override fun send(detail: QueueDetail, sisa: Int, message: String): Boolean {
        // Mode demo: paksa gagal untuk menguji jalur "jadwalkan kirim ulang"
        if (session.simulateSendFailure) return false
        // Notifikasi lokal hanya dapat ditampilkan di perangkat milik pasien yang sedang login
        if (session.userId != detail.queue.userId) return false
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) return false
        val nm = NotificationManagerCompat.from(context)
        if (!nm.areNotificationsEnabled()) return false

        ensureChannel(context)
        val open = PendingIntent.getActivity(
            context, detail.queue.queueId.toInt(),
            Intent(context, MainActivity::class.java).putExtra(MainActivity.EXTRA_TAB, MainActivity.TAB_QUEUE)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val text = "$message\nNomor Anda: ${detail.queue.queueCode}"
        val n = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle(context.getString(R.string.notif_title))
            .setContentText(message)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setContentIntent(open)
            .setAutoCancel(true)
            .build()
        return try {
            nm.notify(detail.queue.queueId.toInt(), n)
            true
        } catch (e: SecurityException) {
            false
        }
    }

    companion object {
        const val CHANNEL_ID = "queue_reminder"

        fun ensureChannel(context: Context) {
            if (Build.VERSION.SDK_INT >= 26) {
                val nm = context.getSystemService(NotificationManager::class.java)
                if (nm.getNotificationChannel(CHANNEL_ID) == null) {
                    val ch = NotificationChannel(
                        CHANNEL_ID, context.getString(R.string.channel_queue_name), NotificationManager.IMPORTANCE_HIGH
                    ).apply { description = context.getString(R.string.channel_queue_desc) }
                    nm.createNotificationChannel(ch)
                }
            }
        }
    }
}
