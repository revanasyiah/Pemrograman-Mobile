package com.example.ruangtunggu

import com.example.ruangtunggu.data.model.Hospital
import com.example.ruangtunggu.data.model.HospitalWithPolis
import com.example.ruangtunggu.data.model.Poli
import com.example.ruangtunggu.data.repository.HospitalSearch
import com.example.ruangtunggu.utils.NotifDecision
import com.example.ruangtunggu.utils.NotifStatus
import com.example.ruangtunggu.utils.NotificationPolicy
import com.example.ruangtunggu.utils.PasswordHasher
import com.example.ruangtunggu.utils.QueueMath
import com.example.ruangtunggu.utils.Validators
import java.time.LocalDate
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ValidatorsTest {
    @Test fun nik_must_be_16_digits() {
        assertTrue(Validators.isNik("3515123456789012"))
        assertFalse(Validators.isNik("3515123"))
        assertFalse(Validators.isNik("35151234567890ab"))
    }

    @Test fun email_and_phone() {
        assertTrue(Validators.isEmail("nama@email.com"))
        assertFalse(Validators.isEmail("nama@"))
        assertTrue(Validators.isPhone("0812345678"))
        assertTrue(Validators.isPhone("+62812345678"))
        assertFalse(Validators.isPhone("0812")) // contoh "Data tidak valid" pada wireframe
    }

    @Test fun password_rule() {
        assertTrue(Validators.isStrongPassword("Afb2r56."))
        assertFalse(Validators.isStrongPassword("abcdefgh"))
        assertFalse(Validators.isStrongPassword("a1"))
    }

    @Test fun birth_parsing() {
        val today = LocalDate.of(2026, 10, 27)
        assertEquals("2005-04-20", Validators.parseDate("20/04/2005", today))
        assertNull(Validators.parseDate("31/02/2005", today))
        assertNull(Validators.parseDate("01/01/2030", today))
        assertEquals("Madiun" to "2005-04-20", Validators.parseBirth("Madiun, 20/04/2005"))
        assertNull(Validators.parseBirth("20/04/2005"))
    }

    @Test fun masking() {
        assertEquals("3515••••••••••••", Validators.maskNik("3515123456789012"))
    }
}

class QueueMathTest {
    @Test fun wireframe_example() {
        // Wireframe: nomor Anda A-023, dilayani A-018 -> sisa 5, estimasi 25 menit
        assertEquals(5, QueueMath.sisa(23, 18))
        assertEquals(25, QueueMath.estimasiMenit(5))
        assertEquals("A-023", QueueMath.code("A", 23))
        assertEquals(listOf(19, 20, 21, 22, 23), QueueMath.upcoming(23, 18))
    }

    @Test fun sisa_never_negative() = assertEquals(0, QueueMath.sisa(10, 12))

    @Test fun notify_threshold() {
        assertFalse(QueueMath.shouldNotify(3, 2))
        assertTrue(QueueMath.shouldNotify(2, 2))
        assertTrue(QueueMath.shouldNotify(0, 2))
    }
}

class NotificationPolicyTest {
    @Test fun skip_when_above_threshold() =
        assertEquals(NotifDecision.SKIP, NotificationPolicy.decide(5, 2, null, 0, 0))

    @Test fun send_first_time_when_within_threshold() =
        assertEquals(NotifDecision.SEND, NotificationPolicy.decide(2, 2, null, 0, 0))

    @Test fun no_duplicate_after_sent() =
        assertEquals(NotifDecision.SKIP, NotificationPolicy.decide(1, 2, NotifStatus.SENT, 0, 1000))

    @Test fun retry_only_when_due() {
        assertEquals(NotifDecision.SKIP, NotificationPolicy.decide(2, 2, NotifStatus.RETRY, 5000, 1000))
        assertEquals(NotifDecision.SEND, NotificationPolicy.decide(2, 2, NotifStatus.RETRY, 5000, 5000))
    }

    @Test fun no_more_attempts_after_final_failure() =
        assertEquals(NotifDecision.SKIP, NotificationPolicy.decide(1, 2, NotifStatus.FAILED, 0, 9999))
}

class HospitalSearchTest {
    private fun hw(id: Long, name: String, vararg polis: String) = HospitalWithPolis(
        Hospital(id, name, "-", "-", 4.8, 1.0, "24 jam", null),
        polis.mapIndexed { i, p -> Poli(id * 10 + i, id, p, "X") }
    )

    private val data = listOf(hw(1, "RS Sehat", "Umum", "Anak"), hw(2, "RS Medika", "Gigi"))

    @Test fun by_hospital_name() = assertEquals(listOf(1L), HospitalSearch.filter(data, "sehat", "Semua").map { it.hospital.hospitalId })

    @Test fun by_poli_name() = assertEquals(listOf(2L), HospitalSearch.filter(data, "gigi", "Semua").map { it.hospital.hospitalId })

    @Test fun not_found_is_empty() = assertTrue(HospitalSearch.filter(data, "Klinik Mawar", "Semua").isEmpty())

    @Test fun poli_filter() = assertEquals(listOf(1L), HospitalSearch.filter(data, "", "Poli Anak").map { it.hospital.hospitalId })
}

class PasswordHasherTest {
    @Test fun hash_verifies_and_is_salted() {
        val s1 = PasswordHasher.newSalt(); val s2 = PasswordHasher.newSalt()
        val h = PasswordHasher.hash("Afb2r56.", s1)
        assertTrue(PasswordHasher.verify("Afb2r56.", s1, h))
        assertFalse(PasswordHasher.verify("salah123", s1, h))
        assertNotEquals(h, PasswordHasher.hash("Afb2r56.", s2))
    }
}
